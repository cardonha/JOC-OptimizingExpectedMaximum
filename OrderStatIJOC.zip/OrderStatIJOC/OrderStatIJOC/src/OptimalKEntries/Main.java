/**
 * This is the main class for the cutting-plane algorithm.
 * 
 * Ref.: Bergman, Cardonha, Lozano, Imbrogno (2018). 
 * 
 * 
 * @author L. Lozano
 * @affiliation University of Cincinnati
 * 
 */
package OptimalKEntries;

import ilog.concert.IloException;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException, InterruptedException, IloException {

		for (int n = 15; n <= 30; n+=5) {
			for (int h = 4; h <= 6; h++) {
				for (int a = 50; a <= 250; a+=50) {
					for (int s = 1; s <= 5; s++) {
						String name=n+"-"+h+"-"+a+"-"+s;
						runTwoEntry(name, 600);
						//runSimulationOpti(name, 600, 2);
					}
				}
			}
		}
	}


	private static void runSingleEntry(String dataFile, int RHS) throws IOException, InterruptedException, IloException {

		// Create output file
		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream("Results Single Entry.txt", true));


		// Read a config file with the instance information
		DataHandler data = new DataHandler(200, 0, 1);
		data.readInstanceTXT("data/leo-"+dataFile);

		// Create an AlgorithmHandler
		AlgorithmHandler alg = new AlgorithmHandler(data);

		// Set cardinality constraint
		data.rhs = RHS;
		// Begin the time count						
		double Atime = System.nanoTime();
		alg.solveSingleEntry(data , ps);

		System.out.println("            EXECUTION TIME: "+((System.nanoTime()-Atime)/1000000000));
		ps.println(((System.nanoTime()-Atime)/1000000000)+" "+alg.mu1Star);

	}

	private static void runTwoEntry(String dataFile , double tLimit) throws IOException, InterruptedException, IloException {

		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream("ResultsExact WEPAPAAP.txt", true));

		// Read a config file with the instance information: Num discrete points for linearization
		DataHandler data = new DataHandler(25, 15, 2);
		data.readInstanceTXT("data/leo-"+dataFile);

		// Create an AlgorithmHandler
		AlgorithmHandler alg = new AlgorithmHandler(data);

		// Begin the time count						
		alg.Atime = System.nanoTime();
		alg.solveSingleEntry(data, ps);
		alg.Heuristic(data, ps);
		alg.genDiscretization(data);
		double timeUsed = ((System.nanoTime()-alg.Atime)/1000000000);
		alg.CuttingPlanes(data , (tLimit-timeUsed), ps);

		System.out.println("            EXECUTION TIME: "+((System.nanoTime()-alg.Atime)/1000000000));
		ps.println(dataFile+" "+((System.nanoTime()-alg.Atime)/1000000000)+" "+alg.zsingle+" "+alg.mu1Star+" "+alg.mu2Star+" "+alg.LB+" "+alg.UB+" "+alg.numCuts+" "+(alg.error/alg.errorCount));
		alg.cplex.clearModel();
		alg.cplex.end();
		System.gc();

	}

	private static void runSimulationOpti(String dataFile , double tLimit, int k) throws IOException, InterruptedException, IloException {

		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream("ResultsSIM-200.txt", true));

		// Read a config file with the instance information: Num discrete points for linearization, num bins
		DataHandler data = new DataHandler(0, 0, 2);
		data.readSimulationInstance(dataFile, 200);

		// Create an AlgorithmHandler
		AlgorithmHandler alg = new AlgorithmHandler(data);

		// Begin the time count						
		alg.Atime = System.nanoTime();
		alg.initM(data);
		alg.solveSimOptiNL(data, tLimit);

		System.out.println("            EXECUTION TIME: "+((System.nanoTime()-alg.Atime)/1000000000));
		ps.println(dataFile+" "+data.numSim+" "+((System.nanoTime()-alg.Atime)/1000000000)+" "+" "+alg.cplex.getMIPRelativeGap()+" "+alg.zsim+" "+alg.zsimREAL);
		alg.cplex.clearModel();
		alg.cplex.end();
		System.gc();

	}



}