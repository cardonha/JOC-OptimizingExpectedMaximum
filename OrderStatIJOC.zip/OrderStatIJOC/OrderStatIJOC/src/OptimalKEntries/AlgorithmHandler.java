/**
 * This class holds all the logic and procedures for hitting a monkey in the face.
 * 
 * Ref.: Lozano, L. and Smith, J. C. (2015). 
 * A Sampling-Based Exact Approach for the Bilevel Mixed Integer Programming Problem
 * 
 * @author L. Lozano & J. C. Smith
 * @affiliation Clemson University
 * @url www.leo-loza.com
 * 
 */

package OptimalKEntries;

import ilog.concert.*;
import ilog.cplex.*;
import ilog.cplex.IloCplex.UnknownObjectException;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Random;

import javax.crypto.spec.GCMParameterSpec;


public class AlgorithmHandler {


	int[][] x;						// Current solution
	double mu1;						// Current mu1
	double mu2;						// Current mu2
	double rho; 					// Current rho

	double zproxy;					// current z value from the master problem
	double Atime;

	double UB;						// Current UB
	double LB;						// Current LB

	int[][] xstar;					 // Optimal first-stage solution
	double mu1Star;					// Optimal mu1
	double mu2Star;					// Optimal mu2
	double rhoStar; 				// Optimal rho


	int[][] ystar;					// Optimal second-stage solutions
	double zstar;					// Optimal objective value

	int numCuts;						// Number of benders cuts
	int iterations;						// Number of solutions explored

	double zsingle;					// Optimal value for the single entry problem
	double zheuristic;				// Value obtained with the heuristic
	double zsim;					// Estimated optimal value for the simulation opti
	double zsimREAL;				// Real monster eval for the simulation opti
	double variance;				// Variance for the oracle evaluations

	double maxThetaSquared;			// Upper bound on theta squared
	double maxTheta;				// Upper bound on theta
	double maxDelta;				// Upper bound on delta

	// For the heuristic
	int Delta;
	int K; 
	double [] expectedVals;

	double error;					//Difference between UB and real obj in the exact two entry method
	int errorCount;					//Number of solutions evaluated
	// Discrete values for theta squared
	double[] intervalLimits1;

	// Discrete values for delta(x)
	double[] intervalLimits2;

	// minimum that thetaS could be for each interval
	double[] minThetaS;


	boolean optimalFound;			// Flag

	int numMoney;					// How many would win money

	double[] optSim; 				// Optimal value for each simulation

	IloCplex cplex;							// Cplex model 1

	Random gR; 								// Global random stream

	public AlgorithmHandler(DataHandler data) throws InterruptedException, IloException {

		numCuts = 0;

		zproxy = Double.POSITIVE_INFINITY;

		x = new int[data.numItems][data.numBins];
		xstar = new int[data.numItems][data.numBins];

		zsingle = 0;
		UB = Double.POSITIVE_INFINITY;
		LB = -Double.POSITIVE_INFINITY;
		optimalFound = false;

		cplex = new IloCplex();

		gR = new Random(0);
		maxThetaSquared = Double.MAX_VALUE;


	}

	public void solveSingleEntry(DataHandler data, PrintStream ps) throws UnknownObjectException, IloException {

		//cplex.setParam(IloCplex.DoubleParam.TiLim, 3600);
		cplex.setOut(null);
		//cplex.setParam(IloCplex.DoubleParam.EpGap, 10E-14);

		IloNumVar[] x = new IloNumVar[data.numItems];

		//Create variables 

		for (int j = 0; j <data.numItems; j++) {
			x[j] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}

		//Add knapsack constraint
		IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			budgetExpr.addTerm(data.coef[j], x[j]);
		}
		cplex.addLe(budgetExpr, data.rhs);

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for (int j = 0; j < data.numItems; j++) {
			obj.addTerm(data.mu[j],x[j]);
			// obj.addTerm(data.realScore[j],x[j]);
		}

		cplex.addMaximize(obj,"Points");
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Single entry is infeasible!");		
		}
		else{
			zsingle = cplex.getObjValue();
			LB = cplex.getObjValue();
			System.out.println("SINGLE ENTRY SOLVED: "+zsingle);
			/*for (int j = 0; j < data.numPlayers; j++) {
				if(cplex.getValue(x[j])>0.1) {this.x[j][0]=1;}
			}
			//solveSubproblem(data , ps);
			 */
			printSolSingleEntry(data);
			mu1Star = zsingle;
			mu2Star = 0;
		}
		cplex.clearModel();	
		cplex.end();
		System.gc();
	}

	public void solveHeuristic(DataHandler data, int Delta, int K ) throws UnknownObjectException, IloException {

		this.Delta = Delta;
		this.K = K;
		expectedVals = new double[data.numBins];

		//cplex.setParam(IloCplex.DoubleParam.TiLim, 3600);
		cplex.setOut(null);
		//cplex.setParam(IloCplex.DoubleParam.EpGap, 10E-14);

		IloNumVar[] x = new IloNumVar[data.numItems];

		//Create variables 

		for (int j = 0; j <data.numItems; j++) {
			x[j] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}

		//Add knapsack constraint
		IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			budgetExpr.addTerm(data.coef[j], x[j]);
		}
		cplex.addLe(budgetExpr, data.rhs);

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for (int j = 0; j < data.numItems; j++) {
			obj.addTerm(data.mu[j],x[j]);
			// obj.addTerm(data.realScore[j],x[j]);
		}

		cplex.addMaximize(obj,"Points");

		for (int h = 0; h < data.numBins; h++) {
			cplex.solve();

			if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
				System.out.println("		HEURISTIC is infeasible after adding some cuts");
			}
			else{
				System.out.println("EXPECTED SCORE "+(h+1)+": "+cplex.getObjValue());
				expectedVals[h] = cplex.getObjValue();
				for (int j = 0; j <data.numItems; j++) {
					this.x[j][h] = (int) Math.round(cplex.getValue(x[j]));
				}

				// Add no-good cut 
				int rhs = 0;
				IloLinearNumExpr exprA = cplex.linearNumExpr();
				for (int j = 0; j <data.numItems; j++) {
					if(this.x[j][h]==1) {
						exprA.addTerm(1, x[j]);
						rhs++;
					}
				}
				cplex.addLe(exprA, rhs-Delta);
				numCuts++;

				// No repeat
				if(data.noRepeat) {
					cplex.addLe(exprA, 0);
				}

				System.out.println("**********************************************NumCuts: "+numCuts+" LB: "+LB+" UB: "+UB);


			}

		}

		if(data.numBins==2) {
			zheuristic = solveSubproblem(data, null);
			System.out.println("HEURISTIC MONSTER EVAL: "+zheuristic);
			printSolSim(data);
		}
		else {
			double sumObj = 0;
			double[] oracleEvals = new double [100]; // Obj evaluation for each oracle batch
			for (int i = 0; i < 100; i++) {
				oracleEvals[i] = evaluateOracle(data, i, K);
				sumObj+=oracleEvals[i];
				//System.out.println(oracleEvals[i]);
			}

			zheuristic = sumObj/(100.0);
			variance = getVariance(oracleEvals, 100);
			System.out.println("ORACLE OBJECTIVE: "+zheuristic+" VARIANCE: "+variance);
			//printSolSim(data);

		}



	}

	private double evaluateOracle(DataHandler data, int batch, int K) {
		double objEval = 0;

		ArrayList<Double> sortedObj; // Sorted expected scores from the worst to the best
		double z = 0;
		for (int q = 0; q <50; q++) {
			sortedObj = new ArrayList<Double>();
			for (int j = 0; j <data.numBins; j++) {
				double score = 0; // Score for the given bin in the simulated vector
				for (int i = 0; i < data.numItems; i++) {
					score+=data.oracle[i][q][batch]*x[i][j];
				}
				//System.out.println("Score for bin "+j+" in oracle vector "+q+" batch "+batch+": "+score);
				putSorted(score, sortedObj);

			}
			z = sortedObj.get(K-1);
			objEval+=(1/50.0)*z;
			//System.out.println("SORTED OBJ: "+sortedObj);
			//System.out.println("z: "+z);
			//System.out.println("objEval: "+objEval);

		}

		return objEval;
	}
	// Function for calculating variance 
	static double getVariance(double a[], int n) { 
		// Compute mean (average of elements) 
		double sum = 0; 
		for (int i = 0; i < n; i++) 
			sum += a[i]; 
		double mean = sum /n; 
		// Compute sum squared differences with mean. 
		double sqDiff = 0; 
		for (int i = 0; i < n; i++)  
			sqDiff += (a[i] - mean)*(a[i] - mean); 

		return (double)sqDiff / (n-1); 
	} 

	private void putSorted(double score, ArrayList<Double> sortedObj) {

		boolean inserted = false;
		for (int i = 0; i < sortedObj.size(); i++) {
			if(score<sortedObj.get(i)) {
				sortedObj.add(i, score);
				inserted=true;
				i = sortedObj.size()+10;
			}
		}
		if(inserted == false) {
			sortedObj.add(score);
		}


	}

	public void solveSimOpti(DataHandler data, double timeLim, int K) throws UnknownObjectException, IloException {
		this.K = K;
		expectedVals = new double[data.numBins];
		cplex = new IloCplex();
		cplex.setParam(IloCplex.DoubleParam.TiLim, timeLim);
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);

		//cplex.setOut(null);

		IloNumVar[][] x = new IloNumVar[data.numItems][data.numBins];  // 1 if item i is selected for bin j
		IloNumVar[][] y = new IloNumVar[data.numBins][data.numSim];  // 1 if bin j is relaxed from the max min constrain in simulation q
		IloNumVar[] z = new IloNumVar[data.numSim];  // Profit for the kth worst bin in simulation q

		//Create variables 
		for (int i = 0; i <data.numItems; i++) {
			for (int j = 0; j <data.numBins; j++) {
				x[i][j] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		for (int j = 0; j <data.numBins; j++) {
			for (int q = 0; q <data.numSim; q++) {
				y[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		for (int q = 0; q <data.numSim; q++) {
			z[q] = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float);
		}

		//Add knapsack constraints
		for (int j = 0; j <data.numBins; j++) {
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int i = 0; i <data.numItems; i++) {
				budgetExpr.addTerm(data.coef[i], x[i][j]);
			}
			cplex.addLe(budgetExpr, data.rhs);
		}

		if(data.noRepeat) {
			for (int j = 0; j < data.numItems; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				for (int q = 0; q < data.numBins; q++) {
					expr.addTerm(1, x[j][q]);	
				}
				cplex.addLe(expr, 1);
			}
		}

		//Add maxmin constraints
		for (int q = 0; q <data.numSim; q++) {
			for (int j = 0; j <data.numBins; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(1, z[q]);
				expr.addTerm(-data.M[q], y[j][q]);
				for (int i = 0; i < data.numItems; i++) {
					expr.addTerm(-data.sim[i][q], x[i][j]);
				}
				cplex.addLe(expr, 0);
			}
		}
		// Define y-variables
		for (int q = 0; q <data.numSim; q++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int j = 0; j <data.numBins; j++) {
				expr.addTerm(1, y[j][q]);
			}
			cplex.addLe(expr, K-1);
		}

		// Anti symmetry constraints
		for (int j = 0; j <data.numBins-1; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int i = 0; i <data.numItems; i++) {
				expr.addTerm(data.sim[i][0], x[i][j]);
			}
			for (int i = 0; i <data.numItems; i++) {
				expr.addTerm(-data.sim[i][0], x[i][j+1]);
			}

			cplex.addGe(expr, 0);
		}


		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for (int q = 0; q < data.numSim; q++) {
			obj.addTerm(1,z[q]);
		}

		cplex.addMaximize(obj,"Profit");
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Simulation Optimization is infeasible!");
			zsim = -1;
		}
		else{
			// Get solution
			zsim = cplex.getObjValue()/data.numSim;
			for (int j = 0; j <data.numBins; j++) {
				expectedVals[j] = 0;
				for (int i = 0; i < data.numItems; i++) {
					if(cplex.getValue(x[i][j])>0.1) {
						this.x[i][j]=1;
						expectedVals[j] += data.mu[i];
					}
				}

			}
			// Use the exact monster evaluation for case bins=2
			if(data.numBins==2) {
				zsimREAL = solveSubproblem(data , null);
				System.out.println("SIMULATION OPTI SOLVED WITH "+data.numSim+" SIMULATIONS");
				System.out.println("OPTIMAL SIMULATED OBJ:"+zsim+" REAL MONSTER EVAL: "+zsimREAL);
				printSolSim(data);			
			}
			else {
				double sumObj = 0;
				double[] oracleEvals = new double [100]; // Obj evaluation for each oracle batch
				for (int i = 0; i < 100; i++) {
					oracleEvals[i] = evaluateOracle(data, i, K);
					sumObj+=oracleEvals[i];
					//System.out.println(oracleEvals[i]);
				}

				zsimREAL = sumObj/(100.0);
				variance = getVariance(oracleEvals, 100);
				System.out.println("ORACLE OBJECTIVE: "+zsimREAL+" VARIANCE: "+variance);
				printSolSim(data);

			}



		}
	}


	public void printSolSim(DataHandler data) {
		for (int j = 0; j <data.numBins; j++) {
			System.out.println("****** Bin "+j);
			for (int i = 0; i < data.numItems; i++) {
				if(x[i][j]>0.1) {System.out.println("Item selected "+i);}
			}
		}

	}

	public void printSolStar(DataHandler data) {
		System.out.println();
		System.out.println("Zstar (monster eval) = "+LB);
		System.out.println("Mu1: "+mu1Star+" Mu2: "+mu2Star+" Rho: "+rhoStar);
		System.out.println("*****First entry:");
		for (int i = 0; i < data.numItems; i++) {
			if(xstar[i][0]>0){System.out.println("Player selected "+i);}
		}
		System.out.println();
		System.out.println("*****Second entry:");		
		for (int i = 0; i < data.numItems; i++) {
			if(xstar[i][1]>0){System.out.println("Player selected "+i);}
		}
	}

	public void printSol(DataHandler data) {
		System.out.println("Zstar (monster eval) = "+LB);
		System.out.println("Mu1: "+mu1+" Mu2: "+mu2+" Rho: "+rho);
		System.out.println("*****First entry:");
		for (int i = 0; i < data.numItems; i++) {
			if(x[i][0]>0){System.out.println(" Player selected "+i);}
		}
		System.out.println();
		System.out.println("*****Second entry:");		
		for (int i = 0; i < data.numItems; i++) {
			if(x[i][1]>0){System.out.println(" Player selected "+i);}
		}
		System.out.println();
	}
	public void printSolSingleEntry(DataHandler data) {
		System.out.println("Zstar (monster eval) = "+LB);
		System.out.println("Mu: "+mu1);
		System.out.println("*****First entry:");
		for (int i = 0; i < data.numItems; i++) {
			if(x[i][0]>0){System.out.println(" Player selected "+i);}
		}
		System.out.println();
	}

	public double solveSubproblem(DataHandler data, PrintStream ps) {
		boolean improvesLB = false;
		//printSol(data);
		// Calculate real monster!!!!

		double mu1 = getmu1(data);
		double mu2 = getmu2(data);
		double theta = gettheta(data); 
		double lb = 0;
		this.mu1 = mu1;
		this.mu2 = mu2;

		Gaussian normal = new Gaussian();

		//			System.out.println("    GOT HERE "+theta);

		if(theta==0) {
			lb = mu1;
		}
		else {
			//System.out.println("WEPAAAAAAAAAAA 2 THETA "+theta);

			lb = mu1*normal.cdf((mu1-mu2)/theta)+mu2*normal.cdf((mu2-mu1)/theta)+theta*normal.pdf((mu1-mu2)/theta);
			//System.out.println("Real Mu1 "+mu1+" Mu2: "+mu2+" ThetaSquared: "+(theta*theta)+" Theta: "+theta+" cdf1: "+normal.cdf((mu1-mu2)/theta)+" cdf2: "+normal.cdf((mu2-mu1)/theta)+" pdf: "+normal.pdf((mu1-mu2)/theta));
		}
		//			System.out.println("    GOT HERE");


		if(lb>=LB) {
			LB = lb;
			improvesLB = true;
			for (int i = 0; i < data.numItems; i++) {
				xstar[i][0]=x[i][0];
				xstar[i][1]=x[i][1];
			}
			mu1Star = this.mu1;
			mu2Star = this.mu2;
			rhoStar = rho;
			//ps.println(((System.nanoTime()-Atime)/1000000000)+" "+zstar+" "+zsingle+" "+mu1Star+" "+mu2Star+" "+LB+" "+UB+" "+numCuts);

			//printSol(data);

		}
		//System.out.println("*********** REAL MONSTER EVAL: "+lb);
		return lb;
	}


	private double gettheta(DataHandler data) {
		double theta = 0;
		double var1=0;
		double var2=0;
		double std1=0;
		double std2=0;
		double rho =0;
		double sumCov = 0;
		// Get variance
		for (int j = 0; j < data.numItems; j++) {
			var1+=data.var[j]*x[j][0];
			var2+=data.var[j]*x[j][1];
		}
		for (int j = 0; j < data.numItems; j++) {
			for (int q = 0; q < data.numItems; q++) {
				if(j!=q) {
					var1+=data.cov[j][q]*x[j][0]*x[q][0];
					var2+=data.cov[j][q]*x[j][1]*x[q][1];
				}
			}
		}
		// Get standard dev
		std1 = Math.sqrt(var1);
		std2 = Math.sqrt(var2);
		// Get sum of cov
		for (int j = 0; j < data.numItems; j++) {
			for (int q = 0; q < data.numItems; q++) {
				sumCov+=data.cov[j][q]*x[j][0]*x[q][1];
			}
		}

		// Get correlation
		double aux = Math.sqrt(var1*var2);
		rho = sumCov/aux;
		if(aux==0) {rho=1;}
		this.rho = rho;
		//		System.out.println("Var1: "+var1+" var2: "+var2+" std1: "+std1+" std2: "+std2+" Cov: "+sumCov+" rho: "+rho+" aux: "+aux);
		//		System.out.println("EY: "+(var1+var2-2*rho*std1*std2));
		theta = Math.sqrt(Math.max(var1+var2-2*rho*std1*std2 , 0));
		return theta;
	}

	private double getmu2(DataHandler data) {
		double mu = 0;

		for (int j = 0; j < data.numItems; j++) {
			mu+=data.mu[j]*x[j][1];
		}

		return mu;
	}

	private double getmu1(DataHandler data) {
		double mu = 0;

		for (int j = 0; j < data.numItems; j++) {
			mu+=data.mu[j]*x[j][0];
		}

		return mu;
	}

	public void Heuristic(DataHandler data, PrintStream ps) throws IloException {

		cplex = new IloCplex();
		cplex.setOut(null);
		cplex.setParam(IloCplex.DoubleParam.TiLim, 60);
		// Upper estimation
		IloNumVar mu1 = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float); // Max between mu1 and mu2
		IloNumVar mu2 = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float); // Min between mu1 and mu2
		IloNumVar[][] x = new IloNumVar[data.numItems][2];

		//Create variables 

		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		//Add budget constraint
		for (int k = 0; k < 2; k++) {
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.numItems; j++) {
				budgetExpr.addTerm(data.coef[j], x[j][k]);
			}
			cplex.addLe(budgetExpr, data.rhs);
		}

		if(data.noRepeat) {
			for (int j = 0; j < data.numItems; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(1, x[j][0]);
				expr.addTerm(1, x[j][1]);
				cplex.addLe(expr, 1);
			}
		}

		// Symmetry breaking
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			exprS.addTerm(data.mu[j], x[j][0]);
			exprS.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addGe(exprS, 0);
		// Add max mu constraints
		IloLinearNumExpr expr = cplex.linearNumExpr();
		IloLinearNumExpr expr2 = cplex.linearNumExpr();
		for (int j = 0; j < data.numItems; j++) {
			expr.addTerm(data.mu[j], x[j][0]);
			expr2.addTerm(data.mu[j], x[j][1]);
		}
		expr.addTerm(-1, mu1);
		expr2.addTerm(-1, mu2);
		cplex.addEq(expr, 0);
		cplex.addEq(expr2, 0);	

		// ENFORCE DECENT TEAMS
		for (int k = 0; k < 2; k++) {
			IloLinearNumExpr exprE = cplex.linearNumExpr();
			for (int j = 0; j < data.numItems; j++) {
				exprE.addTerm(data.mu[j], x[j][k]);
			}
			cplex.addGe(exprE, 0.9*zsingle);
		}

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1 , mu1);
		cplex.addMaximize(obj,"Points");

		cplex.use(new Callback3(x, this,data,ps,cplex));
		cplex.solve();

		//		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
		//			System.out.println("		HEURISTIC is infeasible!");		
		//		}
		if(cplex.getStatus() != IloCplex.Status.Optimal ){

			System.out.println("HEURISTIC DONE!!!!!!!!!!!");
			System.out.println("OBJ HEURISTIC: "+LB);
			zheuristic = LB;
			cplex.clearModel();
			cplex.end();
			System.gc();
			//printSolStar(data);
		}
		else{
			System.out.println("WEPAAAAAAAAA!");
			//	UB = cplex.getObjValue(); 
			/*	for (int k = 0; k < 2; k++) {
				for (int j = 0; j < data.numPlayers; j++) {
					if(cplex.getValue(x[j][k])>0.1)xstar[j][k]=1;
				}
			}

			printSolStar(data);
			 */	

		}


	}

	public void BranchCut4(DataHandler data , double timeLimit, PrintStream ps) throws IloException {
		cplex = new IloCplex();
		numCuts = 0;
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
		cplex.setParam(IloCplex.DoubleParam.CutLo, LB);
		cplex.setParam(IloCplex.DoubleParam.TiLim, timeLimit);

		//cplex.setOut(null);

		// Upper estimation
		IloNumVar thetaSquared = cplex.numVar(0, maxThetaSquared, IloNumVarType.Float);
		IloNumVar theta = cplex.numVar(0, maxTheta, IloNumVarType.Float);
		IloNumVar mu1 = cplex.numVar(0, zsingle, IloNumVarType.Float); // Max between mu1 and mu2
		IloNumVar mu2 = cplex.numVar(0, zsingle, IloNumVarType.Float); // Min between mu1 and mu2
		IloNumVar terms1and2 = cplex.numVar(0, zsingle, IloNumVarType.Float); // First two terms of the upper bounding function
		IloNumVar term3 = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float); // Third term of the upper bounding function
		IloNumVar[][] x = new IloNumVar[data.numItems][2];

		// Linearization variables
		IloNumVar[][][] v = new IloNumVar[data.numItems][data.numItems][2];
		IloNumVar[][] r = new IloNumVar[data.numItems][data.numItems];

		// Discretization variables
		IloNumVar[] w = new IloNumVar[data.numPoints];
		IloNumVar[] y = new IloNumVar[data.numPointsD];

		//Create variables 
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) { v[j][q][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else { v[j][q][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {r[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);}
				else {r[j][q] = cplex.numVar(0, 0, IloNumVarType.Float);}
			}
		}
		for (int i = 0; i <data.numPoints-1; i++) {
			w[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}
		w[data.numPoints-1] = cplex.numVar(0, 0, IloNumVarType.Bool);
		for (int i = 0; i < data.numPointsD-1; i++) {
			y[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}
		y[data.numPointsD-1] = cplex.numVar(0, 0, IloNumVarType.Bool);
		//Add knapsack constraint
		for (int k = 0; k < 2; k++) {
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.numItems; j++) {
				budgetExpr.addTerm(data.coef[j], x[j][k]);
			}
			cplex.addLe(budgetExpr, data.rhs);
		}

		// Add linearization constraints I
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						if(data.cov[j][q]>0) {
							IloLinearNumExpr lExpr = cplex.linearNumExpr();
							lExpr.addTerm(1, v[j][q][k]);
							lExpr.addTerm(-1, x[j][k]);
							cplex.addLe(lExpr, 0);

							IloLinearNumExpr lExprb = cplex.linearNumExpr();
							lExprb.addTerm(1, v[j][q][k]);
							lExprb.addTerm(-1, x[q][k]);
							cplex.addLe(lExprb, 0);
						}
						else if(data.cov[j][q]<0) {
							IloLinearNumExpr lExprc = cplex.linearNumExpr();
							lExprc.addTerm(-1, v[j][q][k]);
							lExprc.addTerm(1, x[j][k]);
							lExprc.addTerm(1, x[q][k]);
							cplex.addLe(lExprc, 1);
						}
					}
				}
			}
		}
		// Add linearization constraints II
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					if(data.cov[j][q]<0) {
						IloLinearNumExpr lExpr = cplex.linearNumExpr();
						lExpr.addTerm(1, r[j][q]);
						lExpr.addTerm(-1, x[j][0]);
						cplex.addLe(lExpr, 0);

						IloLinearNumExpr lExprb = cplex.linearNumExpr();
						lExprb.addTerm(1, r[j][q]);
						lExprb.addTerm(-1, x[q][1]);
						cplex.addLe(lExprb, 0);
					}
					else if(data.cov[j][q]>0) {
						IloLinearNumExpr lExprc = cplex.linearNumExpr();
						lExprc.addTerm(-1, r[j][q]);
						lExprc.addTerm(1, x[j][0]);
						lExprc.addTerm(1, x[q][1]);
						cplex.addLe(lExprc, 1);
					}
				}
			}
		}
		// Add Theta Squared constraint
		IloLinearNumExpr lExpr = cplex.linearNumExpr();
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				lExpr.addTerm(data.var[j], x[j][k]);

				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						lExpr.addTerm(data.cov[j][q], v[j][q][k]);
					}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					lExpr.addTerm(-2*data.cov[j][q], r[j][q]);
				}
			}
		}
		lExpr.addTerm(-1, thetaSquared);
		cplex.addEq(lExpr, 0);

		// Add discretization constraints
		// theta = some image
		IloLinearNumExpr dExpr = cplex.linearNumExpr();
		for (int i = 0; i <data.numPoints-1; i++) {
			dExpr.addTerm(Math.sqrt(intervalLimits1[i+1]), w[i]);
		}
		dExpr.addTerm(-1, theta);
		cplex.addEq(dExpr, 0);
		// Sum of w_i = 1
		IloLinearNumExpr qExpr = cplex.linearNumExpr();
		for (int i = 0; i <data.numPoints-1; i++) {
			qExpr.addTerm(1, w[i]);
		}
		cplex.addEq(qExpr, 1);
		// w_q activation
		for (int i = 0; i < data.numPoints-1; i++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			expr.addTerm(-intervalLimits1[i], w[i]);
			expr.addTerm(1, thetaSquared);
			cplex.addGe(expr, 0);

			IloLinearNumExpr expr2 = cplex.linearNumExpr();
			expr2.addTerm(1, thetaSquared);
			expr2.addTerm( maxThetaSquared, w[i]);
			cplex.addLe(expr2, intervalLimits1[i+1] + maxThetaSquared);

		}
		// Symmetry breaking
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			exprS.addTerm(data.mu[j], x[j][0]);
			exprS.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addGe(exprS, 0);

		// Add mu definition constraints
		IloLinearNumExpr expr = cplex.linearNumExpr();
		IloLinearNumExpr expr2 = cplex.linearNumExpr();
		for (int j = 0; j < data.numItems; j++) {
			expr.addTerm(data.mu[j], x[j][0]);
			expr2.addTerm(data.mu[j], x[j][1]);
		}
		expr.addTerm(-1, mu1);
		expr2.addTerm(-1, mu2);
		cplex.addEq(expr, 0);
		cplex.addEq(expr2, 0);	

		// Mu difference Discretization 
		// y_k activation 
		for (int k = 0; k < data.numPointsD-1; k++) {
			IloLinearNumExpr expr3 = cplex.linearNumExpr();
			expr3.addTerm(1, mu1);
			expr3.addTerm(-1, mu2);
			expr3.addTerm(-intervalLimits2[k], y[k]);
			cplex.addGe(expr3, 0);

			IloLinearNumExpr expr4 = cplex.linearNumExpr();
			expr4.addTerm(1, mu1);
			expr4.addTerm(-1, mu2);
			expr4.addTerm(maxDelta, y[k]);
			cplex.addLe(expr4, intervalLimits2[k+1]+maxDelta);

		}
		// Sum of y_k = 1
		IloLinearNumExpr kExpr = cplex.linearNumExpr();
		for (int k = 0; k <data.numPointsD-1; k++) {
			kExpr.addTerm(1, y[k]);
		}
		cplex.addEq(kExpr, 1);

		// upper bounding function
		Gaussian normal = new Gaussian();
		// Bounds for terms 1 and 2
		for (int q = 0; q < data.numPoints-1; q++) {
			for (int k = 0; k < data.numPointsD-1; k++) {
				IloLinearNumExpr expr3 = cplex.linearNumExpr();
				double cdf;
				if(q==0) {cdf = 1;}
				else {cdf = normal.cdf( (intervalLimits2[k+1])/Math.sqrt(intervalLimits1[q]) )+0.001;}	//0.001 numeric tolerance			
				expr3.addTerm(cdf, mu1);
				expr3.addTerm(1-cdf, mu2);
				expr3.addTerm(-zsingle, y[k]);
				expr3.addTerm(-zsingle, w[q]);
				expr3.addTerm(-1, terms1and2);
				//System.out.println("q: "+q+" k: "+k+" deltaU: "+intervalLimits2[k+1]+" thetaL: "+Math.sqrt(intervalLimits1[q])+" CDF: "+cdf);
				cplex.addGe(expr3, -2*zsingle);
			}

		}
		// Bounds for terms 3
		double M = (1/Math.sqrt(2*Math.PI))*maxTheta; 
		for (int q = 0; q < data.numPoints-1; q++) {
			for (int k = 0; k < data.numPointsD-1; k++) {
				IloLinearNumExpr expr3 = cplex.linearNumExpr();
				double pdf = normal.pdf( (intervalLimits2[k])/Math.sqrt(intervalLimits1[q+1]))+0.001; //0.001 numeric tolerance				
				expr3.addTerm(M, y[k]);
				expr3.addTerm(M, w[q]);
				expr3.addTerm(1, term3);
				System.out.println("q: "+q+" k: "+k+" deltaL: "+intervalLimits2[k]+" thetaU: "+Math.sqrt(intervalLimits1[q+1])+" PDF: "+pdf);
				cplex.addLe(expr3, 2*M+Math.sqrt(intervalLimits1[q+1])*pdf);
			}
		}

		// ADD super valid inequalities minTheta y_k <= thetaSQ
		for (int k = 0; k < data.numPointsD; k++) {
			IloLinearNumExpr expr4 = cplex.linearNumExpr();
			expr4.addTerm(1, thetaSquared);
			expr4.addTerm(-minThetaS[k], y[k]);
			cplex.addGe(expr4, 0);
		}

		// Add bound on delta(x)
		IloLinearNumExpr expr4 = cplex.linearNumExpr();
		expr4.addTerm(1, mu1);
		expr4.addTerm(-1, mu2);
		cplex.addLe(expr4, maxDelta);

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1 , terms1and2);
		obj.addTerm(1 , term3);
		cplex.addMaximize(obj,"ExpectedScore");

		cplex.use(new Callback(x, thetaSquared, theta, mu1, mu2, terms1and2, term3, w, y, this,data, ps, cplex));
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		B&C is infeasible after adding some cuts - OPTIMAL SOL FOUND");
			zstar = LB;
			UB = LB; 
			printSolStar(data);
		}
		else if(!optimalFound ){
			System.out.println("Stop early - TIME LIMIT");
			zstar = -1;
			UB = cplex.getBestObjValue();
		} 
		else{
			zstar = LB;
			UB = LB; 
			printSolStar(data);

			/*	System.out.println("THETA SQUARED: "+cplex.getValue(thetaSquared)+" THETA: "+cplex.getValue(theta));
				System.out.println("mu1: "+cplex.getValue(mu1)+" mu2: "+cplex.getValue(mu2));
				System.out.println("Terms 1 and 2: "+cplex.getValue(terms1and2)+" Term 3: "+cplex.getValue(term3));
				for (int i = 0; i < data.numPoints-1; i++) {
					if(cplex.getValue(w[i])>0.1) System.out.println("w_"+i+" = 1 lowerLimit: "+intervalLimits1[i]+" upper limit: "+intervalLimits1[i+1] );
				}
				for (int i = 0; i < data.numPointsD-1; i++) {
					if(cplex.getValue(y[i])>0.1) System.out.println("y_"+i+" = 1 lowerLimit: "+intervalLimits2[i]+" upper limit: "+intervalLimits2[i+1] );
				}	*/
		}
	}


	public void CuttingPlanesBaseline2(DataHandler data , double timeLimit, PrintStream ps) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);
		numCuts = 0;
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
		cplex.setParam(IloCplex.DoubleParam.CutLo, LB);
		cplex.setParam(IloCplex.DoubleParam.TiLim, timeLimit);

		cplex.setOut(null);

		// Upper estimation
		IloNumVar thetaSquared = cplex.numVar(0, maxThetaSquared, IloNumVarType.Float);
		IloNumVar theta = cplex.numVar(0, maxTheta, IloNumVarType.Float);
		IloNumVar mu1 = cplex.numVar(0, zsingle, IloNumVarType.Float); // Max between mu1 and mu2
		IloNumVar mu2 = cplex.numVar(0, zsingle, IloNumVarType.Float); // Min between mu1 and mu2
		IloNumVar[][] x = new IloNumVar[data.numItems][2];

		// Linearization variables
		IloNumVar[][][] v = new IloNumVar[data.numItems][data.numItems][2];
		IloNumVar[][] r = new IloNumVar[data.numItems][data.numItems];

		// Discretization variables
		IloNumVar[] w = new IloNumVar[data.numPoints];

		//Create variables 
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) { v[j][q][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else { v[j][q][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {r[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);}
				else {r[j][q] = cplex.numVar(0, 0, IloNumVarType.Float);}
			}
		}
		for (int i = 0; i <data.numPoints-1; i++) {
			w[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}
		w[data.numPoints-1] = cplex.numVar(0, 0, IloNumVarType.Bool);
		//Add knapsack constraint
		for (int k = 0; k < 2; k++) {
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.numItems; j++) {
				budgetExpr.addTerm(data.coef[j], x[j][k]);
			}
			cplex.addLe(budgetExpr, data.rhs);
		}
		//Add no repeat
		if(data.noRepeat) {
			for (int j = 0; j < data.numItems; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(1, x[j][0]);
				expr.addTerm(1, x[j][1]);
				cplex.addLe(expr, 1);
			}
		}
		// Add linearization constraints I
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						if(data.cov[j][q]>0) {
							IloLinearNumExpr lExpr = cplex.linearNumExpr();
							lExpr.addTerm(1, v[j][q][k]);
							lExpr.addTerm(-1, x[j][k]);
							cplex.addLe(lExpr, 0);

							IloLinearNumExpr lExprb = cplex.linearNumExpr();
							lExprb.addTerm(1, v[j][q][k]);
							lExprb.addTerm(-1, x[q][k]);
							cplex.addLe(lExprb, 0);
						}
						else if(data.cov[j][q]<0) {
							IloLinearNumExpr lExprc = cplex.linearNumExpr();
							lExprc.addTerm(-1, v[j][q][k]);
							lExprc.addTerm(1, x[j][k]);
							lExprc.addTerm(1, x[q][k]);
							cplex.addLe(lExprc, 1);
						}
					}
				}
			}
		}
		// Add linearization constraints II
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					if(data.cov[j][q]<0) {
						IloLinearNumExpr lExpr = cplex.linearNumExpr();
						lExpr.addTerm(1, r[j][q]);
						lExpr.addTerm(-1, x[j][0]);
						cplex.addLe(lExpr, 0);

						IloLinearNumExpr lExprb = cplex.linearNumExpr();
						lExprb.addTerm(1, r[j][q]);
						lExprb.addTerm(-1, x[q][1]);
						cplex.addLe(lExprb, 0);
					}
					else if(data.cov[j][q]>0) {
						IloLinearNumExpr lExprc = cplex.linearNumExpr();
						lExprc.addTerm(-1, r[j][q]);
						lExprc.addTerm(1, x[j][0]);
						lExprc.addTerm(1, x[q][1]);
						cplex.addLe(lExprc, 1);
					}
				}
			}
		}
		// Add Theta Squared constraint
		IloLinearNumExpr lExpr = cplex.linearNumExpr();
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				lExpr.addTerm(data.var[j], x[j][k]);

				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						lExpr.addTerm(data.cov[j][q], v[j][q][k]);
					}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					lExpr.addTerm(-2*data.cov[j][q], r[j][q]);
				}
			}
		}
		lExpr.addTerm(-1, thetaSquared);
		cplex.addEq(lExpr, 0);

		// Add discretization constraints
		// theta = some image
		IloLinearNumExpr dExpr = cplex.linearNumExpr();
		for (int i = 0; i <data.numPoints-1; i++) {
			dExpr.addTerm(Math.sqrt(intervalLimits1[i+1]), w[i]);
		}
		dExpr.addTerm(-1, theta);
		cplex.addEq(dExpr, 0);
		// Sum of w_i = 1
		IloLinearNumExpr qExpr = cplex.linearNumExpr();
		for (int i = 0; i <data.numPoints-1; i++) {
			qExpr.addTerm(1, w[i]);
		}
		cplex.addEq(qExpr, 1);
		// w_q activation
		for (int i = 0; i < data.numPoints-1; i++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			expr.addTerm(-intervalLimits1[i], w[i]);
			expr.addTerm(1, thetaSquared);
			cplex.addGe(expr, 0);

			IloLinearNumExpr expr2 = cplex.linearNumExpr();
			expr2.addTerm(1, thetaSquared);
			expr2.addTerm( maxThetaSquared, w[i]);
			cplex.addLe(expr2, intervalLimits1[i+1] + maxThetaSquared);

		}
		// Symmetry breaking
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			exprS.addTerm(data.mu[j], x[j][0]);
			exprS.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addGe(exprS, 0);

		// Add mu definition constraints
		IloLinearNumExpr expr = cplex.linearNumExpr();
		IloLinearNumExpr expr2 = cplex.linearNumExpr();
		for (int j = 0; j < data.numItems; j++) {
			expr.addTerm(data.mu[j], x[j][0]);
			expr2.addTerm(data.mu[j], x[j][1]);
		}
		expr.addTerm(-1, mu1);
		expr2.addTerm(-1, mu2);
		cplex.addEq(expr, 0);
		cplex.addEq(expr2, 0);	

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1 , mu1);
		obj.addTerm(1/Math.sqrt(2*Math.PI) , theta);
		cplex.addMaximize(obj,"ExpectedScore");


		//	cplex.use(new CallbackB(x, thetaSquared,  mu1, mu2, this,data, ps, cplex));
		//	cplex.solve();

		boolean stop = false;
		while (stop==false) {
			cplex.solve();

			if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
				System.out.println("		B&C is infeasible after adding some cuts - OPTIMAL SOL FOUND");
				zstar = LB;
				UB = LB; 
				stop = true;
				printSolStar(data);
			}
			else if((System.nanoTime()-Atime)/1000000000<=timeLimit ){
				double timeUsed = ((System.nanoTime()-Atime)/1000000000);
				cplex.setParam(IloCplex.DoubleParam.TiLim, (timeLimit-timeUsed));
				UB = cplex.getObjValue();
				for (int k = 0; k < 2; k++) {
					for (int j = 0; j <data.numItems; j++) {
						this.x[j][k] = (int) Math.round(cplex.getValue(x[j][k]));
					}
				}
				double realObj = solveSubproblem(data , ps);
				double e = ( cplex.getObjValue()  - realObj)/realObj;
				System.out.println("FAKE OBJ: "+( cplex.getObjValue() ) + " REAL OBJ "+realObj+" Error: "+e);
				error+= e;
				errorCount++;

				// Add no-good cut 1 
				int rhs = 0;
				IloLinearNumExpr exprA = cplex.linearNumExpr();
				for (int k = 0; k < 2; k++) {
					for (int j = 0; j <data.numItems; j++) {
						if(this.x[j][k]==1) {
							exprA.addTerm(1, x[j][k]);
							rhs++;
						}
						else {
							exprA.addTerm(-1, x[j][k]);
						}
					}
				}
				cplex.addLe(exprA, rhs-1);
				numCuts++;

				// Add no-good cut 2 (mirror!) 
				IloLinearNumExpr exprB = cplex.linearNumExpr();
				for (int j = 0; j <data.numItems; j++) {
					if(this.x[j][0]==1) {
						exprB.addTerm(1, x[j][1]);
					}
					else {
						exprB.addTerm(-1, x[j][1]);
					}
					if(this.x[j][1]==1) {
						exprB.addTerm(1, x[j][0]);
					}
					else {
						exprB.addTerm(-1, x[j][0]);
					}
				}
				cplex.addLe(exprB, rhs-1);
				numCuts++;

				iterations++;
				if((UB-LB)/UB<0.001) {
					System.out.println("******OPTIMAL CERTIFICATE******NumCuts: "+numCuts+" LB: "+LB+" UB: "+UB);
					optimalFound = true;
					stop = true;
					printSolStar(data);
				}

				System.out.println("**********************************************NumCuts: "+numCuts+" LB: "+LB+" UB: "+UB);


			}
			else {
				System.out.println("Stop early - TIME LIMIT");
				zstar = -1;
				UB = Math.min(UB, cplex.getBestObjValue());
				stop = true;
			} 




		}



	}

	public void CuttingPlanes(DataHandler data , double timeLimit, PrintStream ps) throws IloException {
		cplex = new IloCplex();
		numCuts = 0;
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
		cplex.setParam(IloCplex.DoubleParam.CutLo, LB);
		cplex.setParam(IloCplex.DoubleParam.TiLim, timeLimit);

		cplex.setOut(null);

		// Upper estimation
		IloNumVar thetaSquared = cplex.numVar(0, maxThetaSquared, IloNumVarType.Float);
		//IloNumVar theta = cplex.numVar(0, maxTheta, IloNumVarType.Float);
		IloNumVar mu1 = cplex.numVar(0, zsingle, IloNumVarType.Float); // Max between mu1 and mu2
		IloNumVar mu2 = cplex.numVar(0, zsingle, IloNumVarType.Float); // Min between mu1 and mu2
		IloNumVar terms1and2 = cplex.numVar(0, zsingle, IloNumVarType.Float); // First two terms of the upper bounding function
		IloNumVar term3 = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float); // Third term of the upper bounding function
		IloNumVar[][] x = new IloNumVar[data.numItems][2];

		// Linearization variables
		IloNumVar[][][] v = new IloNumVar[data.numItems][data.numItems][2];
		IloNumVar[][] r = new IloNumVar[data.numItems][data.numItems];

		// Discretization variables
		IloNumVar[] w = new IloNumVar[data.numPoints];
		IloNumVar[] y = new IloNumVar[data.numPointsD];

		//Create variables 
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) { v[j][q][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else { v[j][q][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {r[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);}
				else {r[j][q] = cplex.numVar(0, 0, IloNumVarType.Float);}
			}
		}
		for (int i = 0; i <data.numPoints-1; i++) {
			w[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}
		w[data.numPoints-1] = cplex.numVar(0, 0, IloNumVarType.Bool);
		for (int i = 0; i < data.numPointsD-1; i++) {
			y[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}
		y[data.numPointsD-1] = cplex.numVar(0, 0, IloNumVarType.Bool);
		//Add knapsack constraint
		for (int k = 0; k < 2; k++) {
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.numItems; j++) {
				budgetExpr.addTerm(data.coef[j], x[j][k]);
			}
			cplex.addLe(budgetExpr, data.rhs);
		}
		//Add no repeat
		if(data.noRepeat) {
			for (int j = 0; j < data.numItems; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(1, x[j][0]);
				expr.addTerm(1, x[j][1]);
				cplex.addLe(expr, 1);
			}
		}
		// Add linearization constraints I
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						if(data.cov[j][q]>0) {
							IloLinearNumExpr lExpr = cplex.linearNumExpr();
							lExpr.addTerm(1, v[j][q][k]);
							lExpr.addTerm(-1, x[j][k]);
							cplex.addLe(lExpr, 0);

							IloLinearNumExpr lExprb = cplex.linearNumExpr();
							lExprb.addTerm(1, v[j][q][k]);
							lExprb.addTerm(-1, x[q][k]);
							cplex.addLe(lExprb, 0);
						}
						else if(data.cov[j][q]<0) {
							IloLinearNumExpr lExprc = cplex.linearNumExpr();
							lExprc.addTerm(-1, v[j][q][k]);
							lExprc.addTerm(1, x[j][k]);
							lExprc.addTerm(1, x[q][k]);
							cplex.addLe(lExprc, 1);
						}
					}
				}
			}
		}
		// Add linearization constraints II
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					if(data.cov[j][q]<0) {
						IloLinearNumExpr lExpr = cplex.linearNumExpr();
						lExpr.addTerm(1, r[j][q]);
						lExpr.addTerm(-1, x[j][0]);
						cplex.addLe(lExpr, 0);

						IloLinearNumExpr lExprb = cplex.linearNumExpr();
						lExprb.addTerm(1, r[j][q]);
						lExprb.addTerm(-1, x[q][1]);
						cplex.addLe(lExprb, 0);
					}
					else if(data.cov[j][q]>0) {
						IloLinearNumExpr lExprc = cplex.linearNumExpr();
						lExprc.addTerm(-1, r[j][q]);
						lExprc.addTerm(1, x[j][0]);
						lExprc.addTerm(1, x[q][1]);
						cplex.addLe(lExprc, 1);
					}
				}
			}
		}
		// Add Theta Squared constraint
		IloLinearNumExpr lExpr = cplex.linearNumExpr();
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				lExpr.addTerm(data.var[j], x[j][k]);

				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						lExpr.addTerm(data.cov[j][q], v[j][q][k]);
					}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					lExpr.addTerm(-2*data.cov[j][q], r[j][q]);
				}
			}
		}
		lExpr.addTerm(-1, thetaSquared);
		cplex.addEq(lExpr, 0);

		// Add discretization constraints
		// theta = some image
/*		IloLinearNumExpr dExpr = cplex.linearNumExpr();
		for (int i = 0; i <data.numPoints-1; i++) {
			dExpr.addTerm(Math.sqrt(intervalLimits1[i+1]), w[i]);
		}
		dExpr.addTerm(-1, theta);
		cplex.addEq(dExpr, 0); */
		
		// Sum of w_i = 1
		IloLinearNumExpr qExpr = cplex.linearNumExpr();
		for (int i = 0; i <data.numPoints-1; i++) {
			qExpr.addTerm(1, w[i]);
		}
		cplex.addEq(qExpr, 1);
		// w_q activation
		for (int i = 0; i < data.numPoints-1; i++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			expr.addTerm(-intervalLimits1[i], w[i]);
			expr.addTerm(1, thetaSquared);
			cplex.addGe(expr, 0);

			IloLinearNumExpr expr2 = cplex.linearNumExpr();
			expr2.addTerm(1, thetaSquared);
			expr2.addTerm( maxThetaSquared, w[i]);
			cplex.addLe(expr2, intervalLimits1[i+1] + maxThetaSquared);

		}
		// Symmetry breaking
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			exprS.addTerm(data.mu[j], x[j][0]);
			exprS.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addGe(exprS, 0);

		// Add mu definition constraints
		IloLinearNumExpr expr = cplex.linearNumExpr();
		IloLinearNumExpr expr2 = cplex.linearNumExpr();
		for (int j = 0; j < data.numItems; j++) {
			expr.addTerm(data.mu[j], x[j][0]);
			expr2.addTerm(data.mu[j], x[j][1]);
		}
		expr.addTerm(-1, mu1);
		expr2.addTerm(-1, mu2);
		cplex.addEq(expr, 0);
		cplex.addEq(expr2, 0);	

		// Mu difference Discretization 
		// y_k activation 
		for (int k = 0; k < data.numPointsD-1; k++) {
			IloLinearNumExpr expr3 = cplex.linearNumExpr();
			expr3.addTerm(1, mu1);
			expr3.addTerm(-1, mu2);
			expr3.addTerm(-intervalLimits2[k], y[k]);
			cplex.addGe(expr3, 0);

			IloLinearNumExpr expr4 = cplex.linearNumExpr();
			expr4.addTerm(1, mu1);
			expr4.addTerm(-1, mu2);
			expr4.addTerm(maxDelta, y[k]);
			cplex.addLe(expr4, intervalLimits2[k+1]+maxDelta);

		}
		// Sum of y_k = 1
		IloLinearNumExpr kExpr = cplex.linearNumExpr();
		for (int k = 0; k <data.numPointsD-1; k++) {
			kExpr.addTerm(1, y[k]);
		}
		cplex.addEq(kExpr, 1);

		// upper bounding function
		Gaussian normal = new Gaussian();
		// Bounds for terms 1 and 2
		for (int q = 0; q < data.numPoints-1; q++) {
			for (int k = 0; k < data.numPointsD-1; k++) {
				IloLinearNumExpr expr3 = cplex.linearNumExpr();
				double cdf;
				if(q==0) {cdf = 1;}
				else {cdf = normal.cdf( (intervalLimits2[k+1])/Math.sqrt(intervalLimits1[q]) )+0.001;}	//0.001 numeric tolerance			
				expr3.addTerm(cdf, mu1);
				expr3.addTerm(1-cdf, mu2);
				expr3.addTerm(-zsingle, y[k]);
				expr3.addTerm(-zsingle, w[q]);
				expr3.addTerm(-1, terms1and2);
				//System.out.println("q: "+q+" k: "+k+" deltaU: "+intervalLimits2[k+1]+" thetaL: "+Math.sqrt(intervalLimits1[q])+" CDF: "+cdf);
				cplex.addGe(expr3, -2*zsingle);
			}

		}
		// Bounds for terms 3
		double M = (1/Math.sqrt(2*Math.PI))*maxTheta; 
		for (int q = 0; q < data.numPoints-1; q++) {
			for (int k = 0; k < data.numPointsD-1; k++) {
				IloLinearNumExpr expr3 = cplex.linearNumExpr();
				double pdf = normal.pdf( (intervalLimits2[k])/Math.sqrt(intervalLimits1[q+1]))+0.001; //0.001 numeric tolerance				
				expr3.addTerm(M, y[k]);
				expr3.addTerm(M, w[q]);
				expr3.addTerm(1, term3);
				//System.out.println("q: "+q+" k: "+k+" deltaL: "+intervalLimits2[k]+" thetaU: "+Math.sqrt(intervalLimits1[q+1])+" PDF: "+pdf);
				cplex.addLe(expr3, 2*M+Math.sqrt(intervalLimits1[q+1])*pdf);
			}
		}

		// ADD super valid inequalities minTheta y_k <= thetaSQ
		for (int k = 0; k < data.numPointsD; k++) {
			IloLinearNumExpr expr4 = cplex.linearNumExpr();
			expr4.addTerm(1, thetaSquared);
			expr4.addTerm(-minThetaS[k], y[k]);
			cplex.addGe(expr4, 0);
		}

		// Add bound on delta(x)
		IloLinearNumExpr expr4 = cplex.linearNumExpr();
		expr4.addTerm(1, mu1);
		expr4.addTerm(-1, mu2);
		cplex.addLe(expr4, maxDelta);

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1 , terms1and2);
		obj.addTerm(1 , term3);
		cplex.addMaximize(obj,"ExpectedScore");


		boolean stop = false;
		while (stop==false) {
			cplex.solve();

			if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
				System.out.println("		B&C is infeasible after adding some cuts - OPTIMAL SOL FOUND");
				zstar = LB;
				UB = LB; 
				stop = true;
				printSolStar(data);
			}
			else if((System.nanoTime()-Atime)/1000000000<=timeLimit ){
				/*	System.out.println("THETA SQUARED: "+cplex.getValue(thetaSquared)+" THETA: "+cplex.getValue(theta));
			System.out.println("mu1: "+cplex.getValue(mu1)+" mu2: "+cplex.getValue(mu2));
			System.out.println("Terms 1 and 2: "+cplex.getValue(terms1and2)+" Term 3: "+cplex.getValue(term3));
			for (int i = 0; i < data.numPoints-1; i++) {
				if(cplex.getValue(w[i])>0.1) System.out.println("w_"+i+" = 1 lowerLimit: "+intervalLimits1[i]+" upper limit: "+intervalLimits1[i+1] );
			}
			for (int i = 0; i < data.numPointsD-1; i++) {
				if(cplex.getValue(y[i])>0.1) System.out.println("y_"+i+" = 1 lowerLimit: "+intervalLimits2[i]+" upper limit: "+intervalLimits2[i+1] );
			}	*/
				double timeUsed = ((System.nanoTime()-Atime)/1000000000);
				cplex.setParam(IloCplex.DoubleParam.TiLim, (timeLimit-timeUsed));

				UB = cplex.getObjValue();
				for (int k = 0; k < 2; k++) {
					for (int j = 0; j <data.numItems; j++) {
						this.x[j][k] = (int) Math.round(cplex.getValue(x[j][k]));
					}
				}
				double realObj = solveSubproblem(data , ps);
				double e = ( cplex.getValue(terms1and2)+cplex.getValue(term3)  - realObj)/realObj;
				System.out.println("FAKE OBJ: "+( cplex.getValue(terms1and2)+cplex.getValue(term3) ) + " REAL OBJ "+realObj+" Error: "+e);
				error+= e;
				errorCount++;

				// Add no-good cut 1 
				int rhs = 0;
				IloLinearNumExpr exprA = cplex.linearNumExpr();
				for (int k = 0; k < 2; k++) {
					for (int j = 0; j <data.numItems; j++) {
						if(this.x[j][k]==1) {
							exprA.addTerm(1, x[j][k]);
							rhs++;
						}
						else {
							exprA.addTerm(-1, x[j][k]);
						}
					}
				}
				cplex.addLe(exprA, rhs-1);
				numCuts++;

				// Add no-good cut 2 (mirror!) 
				IloLinearNumExpr exprB = cplex.linearNumExpr();
				for (int j = 0; j <data.numItems; j++) {
					if(this.x[j][0]==1) {
						exprB.addTerm(1, x[j][1]);
					}
					else {
						exprB.addTerm(-1, x[j][1]);
					}
					if(this.x[j][1]==1) {
						exprB.addTerm(1, x[j][0]);
					}
					else {
						exprB.addTerm(-1, x[j][0]);
					}
				}
				cplex.addLe(exprB, rhs-1);
				numCuts++;

				iterations++;
				if((UB-LB)/UB<0.001) {
					System.out.println("******OPTIMAL CERTIFICATE******NumCuts: "+numCuts+" LB: "+LB+" UB: "+UB);
					optimalFound = true;
					stop = true;
					printSolStar(data);
				}

				System.out.println("**********************************************NumCuts: "+numCuts+" LB: "+LB+" UB: "+UB);


			}
			else {
				System.out.println("Stop early - TIME LIMIT");
				zstar = -1;
				UB = Math.min(UB, cplex.getBestObjValue());
				stop = true;
			} 




		}



	}

	public void CuttingPlanesBaseline(DataHandler data , double timeLimit, PrintStream ps) throws IloException {
		cplex = new IloCplex();
		numCuts = 0;
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
		cplex.setParam(IloCplex.DoubleParam.CutLo, LB);
		cplex.setParam(IloCplex.DoubleParam.TiLim, timeLimit);

		//cplex.setOut(null);

		// Upper estimation
		IloNumVar thetaSquared = cplex.numVar(0, maxThetaSquared, IloNumVarType.Float);
		IloNumVar mu1 = cplex.numVar(0, zsingle, IloNumVarType.Float); // Max between mu1 and mu2
		IloNumVar mu2 = cplex.numVar(0, zsingle, IloNumVarType.Float); // Min between mu1 and mu2
		IloNumVar[][] x = new IloNumVar[data.numItems][2];

		// Linearization variables
		IloNumVar[][][] v = new IloNumVar[data.numItems][data.numItems][2];
		IloNumVar[][] r = new IloNumVar[data.numItems][data.numItems];

		//Create variables 
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) { v[j][q][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else { v[j][q][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {r[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);}
				else {r[j][q] = cplex.numVar(0, 0, IloNumVarType.Float);}
			}
		}
		//Add knapsack constraint
		for (int k = 0; k < 2; k++) {
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.numItems; j++) {
				budgetExpr.addTerm(data.coef[j], x[j][k]);
			}
			cplex.addLe(budgetExpr, data.rhs);
		}
		//Add no repeat
		if(data.noRepeat) {
			for (int j = 0; j < data.numItems; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(1, x[j][0]);
				expr.addTerm(1, x[j][1]);
				cplex.addLe(expr, 1);
			}
		}
		// Add linearization constraints I
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						if(data.cov[j][q]>0) {
							IloLinearNumExpr lExpr = cplex.linearNumExpr();
							lExpr.addTerm(1, v[j][q][k]);
							lExpr.addTerm(-1, x[j][k]);
							cplex.addLe(lExpr, 0);

							IloLinearNumExpr lExprb = cplex.linearNumExpr();
							lExprb.addTerm(1, v[j][q][k]);
							lExprb.addTerm(-1, x[q][k]);
							cplex.addLe(lExprb, 0);
						}
						else if(data.cov[j][q]<0) {
							IloLinearNumExpr lExprc = cplex.linearNumExpr();
							lExprc.addTerm(-1, v[j][q][k]);
							lExprc.addTerm(1, x[j][k]);
							lExprc.addTerm(1, x[q][k]);
							cplex.addLe(lExprc, 1);
						}
					}
				}
			}
		}
		// Add linearization constraints II
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					if(data.cov[j][q]<0) {
						IloLinearNumExpr lExpr = cplex.linearNumExpr();
						lExpr.addTerm(1, r[j][q]);
						lExpr.addTerm(-1, x[j][0]);
						cplex.addLe(lExpr, 0);

						IloLinearNumExpr lExprb = cplex.linearNumExpr();
						lExprb.addTerm(1, r[j][q]);
						lExprb.addTerm(-1, x[q][1]);
						cplex.addLe(lExprb, 0);
					}
					else if(data.cov[j][q]>0) {
						IloLinearNumExpr lExprc = cplex.linearNumExpr();
						lExprc.addTerm(-1, r[j][q]);
						lExprc.addTerm(1, x[j][0]);
						lExprc.addTerm(1, x[q][1]);
						cplex.addLe(lExprc, 1);
					}
				}
			}
		}
		// Add Theta Squared constraint
		IloLinearNumExpr lExpr = cplex.linearNumExpr();
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				lExpr.addTerm(data.var[j], x[j][k]);

				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						lExpr.addTerm(data.cov[j][q], v[j][q][k]);
					}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					lExpr.addTerm(-2*data.cov[j][q], r[j][q]);
				}
			}
		}
		lExpr.addTerm(-1, thetaSquared);
		cplex.addEq(lExpr, 0);

		// Symmetry breaking
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			exprS.addTerm(data.mu[j], x[j][0]);
			exprS.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addGe(exprS, 0);

		// Add mu definition constraints
		IloLinearNumExpr expr = cplex.linearNumExpr();
		IloLinearNumExpr expr2 = cplex.linearNumExpr();
		for (int j = 0; j < data.numItems; j++) {
			expr.addTerm(data.mu[j], x[j][0]);
			expr2.addTerm(data.mu[j], x[j][1]);
		}
		expr.addTerm(-1, mu1);
		expr2.addTerm(-1, mu2);
		cplex.addEq(expr, 0);
		cplex.addEq(expr2, 0);	

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1 , mu1);
		obj.addTerm(1/Math.sqrt(2*Math.PI) , thetaSquared);
		//obj.addTerm(1 , thetaSquared);
		cplex.addMaximize(obj,"ExpectedScore");

		cplex.use(new CallbackB(x, thetaSquared,  mu1, mu2, this,data, ps, cplex));
		cplex.solve();


		//	boolean stop = false;
		//	while (stop==false) {
		//		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		B&C is infeasible after adding some cuts - OPTIMAL SOL FOUND");
			zstar = LB;
			UB = LB; 
			//			stop = true;
			printSolStar(data);
		}
		else if((System.nanoTime()-Atime)/1000000000<=timeLimit ){
			/*	System.out.println("THETA SQUARED: "+cplex.getValue(thetaSquared));
			System.out.println("mu1: "+cplex.getValue(mu1)+" mu2: "+cplex.getValue(mu2));

			UB = cplex.getObjValue()+1/Math.sqrt(2*Math.PI);
	  		  for (int k = 0; k < 2; k++) {
				  for (int j = 0; j <data.numItems; j++) {
					  this.x[j][k] = (int) Math.round(cplex.getValue(x[j][k]));
				  }
			  }
			double realObj = solveSubproblem(data , ps);
			double e = ( UB  - realObj)/realObj;
			System.out.println("FAKE OBJ: "+( UB ) + " REAL OBJ "+realObj+" Error: "+e);
			error+= e;
			errorCount++;

			// Add no-good cut 1 
			int rhs = 0;
			IloLinearNumExpr exprA = cplex.linearNumExpr();
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numItems; j++) {
					if(this.x[j][k]==1) {
						exprA.addTerm(1, x[j][k]);
						rhs++;
					}
					else {
						exprA.addTerm(-1, x[j][k]);
					}
				}
			}
			cplex.addLe(exprA, rhs-1);
			numCuts++;

			// Add no-good cut 2 (mirror!) 
			IloLinearNumExpr exprB = cplex.linearNumExpr();
			for (int j = 0; j <data.numItems; j++) {
				if(this.x[j][0]==1) {
					exprB.addTerm(1, x[j][1]);
				}
				else {
					exprB.addTerm(-1, x[j][1]);
				}
				if(this.x[j][1]==1) {
					exprB.addTerm(1, x[j][0]);
				}
				else {
					exprB.addTerm(-1, x[j][0]);
				}
			}
			cplex.addLe(exprB, rhs-1);
			numCuts++;

			iterations++;
			if((UB-LB)/UB<0.001) {
				System.out.println("******OPTIMAL CERTIFICATE******NumCuts: "+numCuts+" LB: "+LB+" UB: "+UB);
				optimalFound = true;
				stop = true;
				printSolStar(data);
			}

			System.out.println("**********************************************NumCuts: "+numCuts+" LB: "+LB+" UB: "+UB);

			 */		
		}
		else {
			System.out.println("Stop early - TIME LIMIT");
			zstar = -1;
			UB = Math.min(UB, cplex.getBestObjValue());
			//		        stop = true;
		} 

		//}



	}



	public void genDiscretization(DataHandler data) throws IloException {
		getMaxThetaS(data);		// Compute an upper bound on theta squared and theta
		genThetaLinPoints(data);
		getMaxDelta(data);		// Compute an upper bound on delta (x) and build the intervals
		//		genDeltaLinPoints2(data);

		// Get min theta
		minThetaS = new double[data.numPointsD];
		double step = (maxDelta)/(data.numPointsD-1);
		for (int i = 0; i < intervalLimits2.length; i++) {
			double minTheta = calcMinTheta(intervalLimits2[i]);
			minThetaS[i] = minTheta*minTheta;
			//System.out.println("interval: "+intervalLimits2[i]+" MINTHETASQ: "+minThetaS[i]);		
		}

		/*		System.out.println("THETA INTERVALS: ");
		for (int i = 0; i < intervalLimits1.length; i++) {
			System.out.print(intervalLimits1[i]+" ");
		}
		System.out.println();

		System.out.println("DELTA INTERVALS: ");
		for (int i = 0; i < intervalLimits2.length; i++) {
			System.out.print(intervalLimits2[i]+" ");
		}
		System.out.println();
		 */	


	}


	private double calcMinTheta(double delta) {
		Gaussian normal = new Gaussian();
		double minT = 0.00000001;
		double obj = 0;

		while(obj < LB) {
			minT+=0.01;
			obj = zsingle+minT*normal.pdf((delta)/minT);
			//System.out.println("MIN T: "+minT+" OBJ: "+obj);
		}
		return minT-0.01;
	}
	private void genThetaLinPoints(DataHandler data) {
		// Gen Discretization points
		intervalLimits1 = new double[data.numPoints];

		intervalLimits1[0] = 0;
		intervalLimits1[1] = 1;

		double step = (maxThetaSquared-1)/(data.numPoints-2);
		for (int i = 2; i < data.numPoints; i++) {
			intervalLimits1[i] = intervalLimits1[i-1]+step;
		}


	}

	private void genDeltaLinPoints(DataHandler data) {
		// Gen Discretization points
		intervalLimits2 = new double[data.numPointsD];

		double step = (maxDelta)/(data.numPointsD-1);
		for (int i = 0; i < data.numPointsD; i++) {
			intervalLimits2[i] = 0+step*i;
		}


	}


	private void genDeltaLinPoints2(DataHandler data) {

		//Get max delta
		double minTheta = 0;
		double delta = 0;
		while (minTheta <= maxTheta) {
			minTheta = calcMinTheta(delta);
			System.out.println("DELTA: "+delta+" MINTHETA: "+minTheta);
			delta+=0.1;
		}
		maxDelta = delta;
		System.out.println("MAX DELTA "+delta);	

		// Gen Discretization points
		intervalLimits2 = new double[data.numPointsD];

		double step = (maxDelta)/(data.numPointsD-1);
		for (int i = 0; i < data.numPointsD; i++) {
			intervalLimits2[i] = 0+step*i;
		}


	}


	public void getMaxThetaS(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
		cplex.setParam(IloCplex.DoubleParam.TiLim, 120);
		cplex.setOut(null);

		// Upper estimation
		IloNumVar thetaSquared = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float);
		IloNumVar[][] x = new IloNumVar[data.numItems][2];

		// Linearization variables
		IloNumVar[][][] v = new IloNumVar[data.numItems][data.numItems][2];
		IloNumVar[][] r = new IloNumVar[data.numItems][data.numItems];

		//Create variables 
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) { v[j][q][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else { v[j][q][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {r[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);}
				else {r[j][q] = cplex.numVar(0, 0, IloNumVarType.Float);}
			}
		}
		//Add BUDGET constraint
		for (int k = 0; k < 2; k++) {
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.numItems; j++) {
				budgetExpr.addTerm(data.coef[j], x[j][k]);
			}
			cplex.addLe(budgetExpr, data.rhs);
		}
		//Add no repeat
		if(data.noRepeat) {
			for (int j = 0; j < data.numItems; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(1, x[j][0]);
				expr.addTerm(1, x[j][1]);
				cplex.addLe(expr, 1);
			}
		}
		// Add linearization constraints I
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						if(data.cov[j][q]>0) {
							IloLinearNumExpr lExpr = cplex.linearNumExpr();
							lExpr.addTerm(1, v[j][q][k]);
							lExpr.addTerm(-1, x[j][k]);
							cplex.addLe(lExpr, 0);

							IloLinearNumExpr lExprb = cplex.linearNumExpr();
							lExprb.addTerm(1, v[j][q][k]);
							lExprb.addTerm(-1, x[q][k]);
							cplex.addLe(lExprb, 0);
						}
						else if(data.cov[j][q]<0) {
							IloLinearNumExpr lExprc = cplex.linearNumExpr();
							lExprc.addTerm(-1, v[j][q][k]);
							lExprc.addTerm(1, x[j][k]);
							lExprc.addTerm(1, x[q][k]);
							cplex.addLe(lExprc, 1);
						}
					}
				}
			}
		}
		// Add linearization constraints II
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					if(data.cov[j][q]<0) {
						IloLinearNumExpr lExpr = cplex.linearNumExpr();
						lExpr.addTerm(1, r[j][q]);
						lExpr.addTerm(-1, x[j][0]);
						cplex.addLe(lExpr, 0);

						IloLinearNumExpr lExprb = cplex.linearNumExpr();
						lExprb.addTerm(1, r[j][q]);
						lExprb.addTerm(-1, x[q][1]);
						cplex.addLe(lExprb, 0);
					}
					else if(data.cov[j][q]>0) {
						IloLinearNumExpr lExprc = cplex.linearNumExpr();
						lExprc.addTerm(-1, r[j][q]);
						lExprc.addTerm(1, x[j][0]);
						lExprc.addTerm(1, x[q][1]);
						cplex.addLe(lExprc, 1);
					}
				}
			}
		}
		// Add Theta Squared constraint
		IloLinearNumExpr lExpr = cplex.linearNumExpr();
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				lExpr.addTerm(data.var[j], x[j][k]);

				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						lExpr.addTerm(data.cov[j][q], v[j][q][k]);
					}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					lExpr.addTerm(-2*data.cov[j][q], r[j][q]);
				}
			}
		}
		lExpr.addTerm(-1, thetaSquared);
		cplex.addEq(lExpr, 0);
		// Symmetry breaking
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			exprS.addTerm(data.mu[j], x[j][0]);
			exprS.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addGe(exprS, 0);

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1, thetaSquared);
		cplex.addMaximize(obj,"ThetaSquared");
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Theta Bounder is infeasible!");		
		}
		else{
			maxThetaSquared = cplex.getBestObjValue();
			maxTheta = Math.sqrt(maxThetaSquared);
			System.out.println("MAX THETA SQUARED IS: "+maxThetaSquared+" MAX THETA: "+maxTheta);

			cplex.clearModel();
			cplex.end();
			System.gc();
		}
	}


	public void getMaxDelta(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
		cplex.setParam(IloCplex.DoubleParam.TiLim, 120);
		cplex.setOut(null);

		// Upper estimation
		IloNumVar thetaSquared = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float);
		IloNumVar[][] x = new IloNumVar[data.numItems][2];

		// Linearization variables
		IloNumVar[][][] v = new IloNumVar[data.numItems][data.numItems][2];
		IloNumVar[][] r = new IloNumVar[data.numItems][data.numItems];

		//Create variables 
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) { v[j][q][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else { v[j][q][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {r[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);}
				else {r[j][q] = cplex.numVar(0, 0, IloNumVarType.Float);}
			}
		}
		//Add BUDGET constraint
		for (int k = 0; k < 2; k++) {
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.numItems; j++) {
				budgetExpr.addTerm(data.coef[j], x[j][k]);
			}
			cplex.addLe(budgetExpr, data.rhs);
		}
		//Add cardinality constraint
		if(data.noRepeat) {
			for (int j = 0; j < data.numItems; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(1, x[j][0]);
				expr.addTerm(1, x[j][1]);
				cplex.addLe(expr, 1);
			}
		}
		// Add linearization constraints I
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						if(data.cov[j][q]>0) {
							IloLinearNumExpr lExpr = cplex.linearNumExpr();
							lExpr.addTerm(1, v[j][q][k]);
							lExpr.addTerm(-1, x[j][k]);
							cplex.addLe(lExpr, 0);

							IloLinearNumExpr lExprb = cplex.linearNumExpr();
							lExprb.addTerm(1, v[j][q][k]);
							lExprb.addTerm(-1, x[q][k]);
							cplex.addLe(lExprb, 0);
						}
						else if(data.cov[j][q]<0) {
							IloLinearNumExpr lExprc = cplex.linearNumExpr();
							lExprc.addTerm(-1, v[j][q][k]);
							lExprc.addTerm(1, x[j][k]);
							lExprc.addTerm(1, x[q][k]);
							cplex.addLe(lExprc, 1);
						}
					}
				}
			}
		}
		// Add linearization constraints II
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					if(data.cov[j][q]<0) {
						IloLinearNumExpr lExpr = cplex.linearNumExpr();
						lExpr.addTerm(1, r[j][q]);
						lExpr.addTerm(-1, x[j][0]);
						cplex.addLe(lExpr, 0);

						IloLinearNumExpr lExprb = cplex.linearNumExpr();
						lExprb.addTerm(1, r[j][q]);
						lExprb.addTerm(-1, x[q][1]);
						cplex.addLe(lExprb, 0);
					}
					else if(data.cov[j][q]>0) {
						IloLinearNumExpr lExprc = cplex.linearNumExpr();
						lExprc.addTerm(-1, r[j][q]);
						lExprc.addTerm(1, x[j][0]);
						lExprc.addTerm(1, x[q][1]);
						cplex.addLe(lExprc, 1);
					}
				}
			}
		}
		// Add Theta Squared constraint
		IloLinearNumExpr lExpr = cplex.linearNumExpr();
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				lExpr.addTerm(data.var[j], x[j][k]);

				for (int q = 0; q <data.numItems; q++) {
					if(j!=q && data.cov[j][q]!=0) {
						lExpr.addTerm(data.cov[j][q], v[j][q][k]);
					}
				}
			}
		}
		for (int j = 0; j <data.numItems; j++) {
			for (int q = 0; q <data.numItems; q++) {
				if(data.cov[j][q]!=0) {
					lExpr.addTerm(-2*data.cov[j][q], r[j][q]);
				}
			}
		}
		lExpr.addTerm(-1, thetaSquared);
		cplex.addEq(lExpr, 0);
		// Symmetry breaking
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			exprS.addTerm(data.mu[j], x[j][0]);
			exprS.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addGe(exprS, 0);

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			obj.addTerm(data.mu[j], x[j][0]);
			obj.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addMaximize(obj,"Delta");
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		DELTA Bounder is infeasible!");		
		}
		else{
			maxDelta = cplex.getBestObjValue();
			System.out.println("MAX DELTA "+maxDelta);	

			// Gen Discretization points
			intervalLimits2 = new double[data.numPointsD];

			double step = (maxDelta)/(data.numPointsD-1);
			for (int i = 0; i < data.numPointsD; i++) {
				intervalLimits2[i] = 0+step*i;
			}

			cplex.clearModel();
			cplex.end();
			System.gc();
		}
	}

	public void initM(DataHandler data) throws IloException {
		System.out.println("INITIALIZING M VECTOR");
		data.M = new double[data.numSim];
		for (int q = 0; q < data.numSim; q++) {
			solveSingleEntrySim(data, q);
		}

	}

	private void solveSingleEntrySim(DataHandler data, int q) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);
		IloNumVar[] x = new IloNumVar[data.numItems];

		//Create variables 
		for (int j = 0; j <data.numItems; j++) {
			x[j] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}

		//Add knapsack constraint
		IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			budgetExpr.addTerm(data.coef[j], x[j]);
		}
		cplex.addLe(budgetExpr, data.rhs);

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for (int j = 0; j < data.numItems; j++) {
			obj.addTerm(data.sim[j][q],x[j]);
		}

		cplex.addMaximize(obj,"Points");
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Single entry SIM is infeasible!");		
		}
		else{
			//System.out.println("SINGLE ENTRY SIM SOLVED: "+cplex.getObjValue());
			data.M[q] = cplex.getObjValue();
		}
		cplex.clearModel();	
		cplex.end();
		System.gc();

	}

	public void solveSimOptiNL(DataHandler data, double tLimit) throws IloException {

		expectedVals = new double[data.numBins];
		cplex = new IloCplex();
		cplex.setParam(IloCplex.DoubleParam.TiLim, tLimit);
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);

		cplex.setOut(null);

		IloNumVar[][] x = new IloNumVar[data.numItems][data.numBins];  // 1 if item i is selected for bin j
		IloNumVar[] y = new IloNumVar [data.numSim];  // Binary to linearize |E1-E2| in simulation q
		IloNumVar[][] z = new IloNumVar[data.numSim][data.numBins];  // Profit for both bin in simulation q
		IloNumVar[] devplus = new IloNumVar[data.numSim];  // Positive part of the absolute value
		IloNumVar[] devminus = new IloNumVar[data.numSim];  // negative part of the absolute value

		//Create variables 
		for (int i = 0; i <data.numItems; i++) {
			for (int j = 0; j <data.numBins; j++) {
				x[i][j] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		for (int q = 0; q <data.numSim; q++) {
			y[q] = cplex.numVar(0, 1, IloNumVarType.Bool);
			devplus[q] = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float);
			devminus[q] = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float);
		}

		for (int q = 0; q <data.numSim; q++) {
			for (int j = 0; j <data.numBins; j++) {
				z[q][j] = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float);
			}
		}

		//Add knapsack constraints
		for (int j = 0; j <data.numBins; j++) {
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int i = 0; i <data.numItems; i++) {
				budgetExpr.addTerm(data.coef[i], x[i][j]);
			}
			cplex.addLe(budgetExpr, data.rhs);
		}

		if(data.noRepeat) {
			for (int j = 0; j < data.numItems; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				for (int q = 0; q < data.numBins; q++) {
					expr.addTerm(1, x[j][q]);	
				}
				cplex.addLe(expr, 1);
			}
		}

		//Define z variables
		for (int q = 0; q <data.numSim; q++) {
			for (int j = 0; j <data.numBins; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(1, z[q][j]);
				for (int i = 0; i < data.numItems; i++) {
					expr.addTerm(-data.sim[i][q], x[i][j]);
				}
				cplex.addLe(expr, 0);
			}
		}

		//Define absolute value
		for (int q = 0; q <data.numSim; q++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			expr.addTerm(1, z[q][0]);
			expr.addTerm(-1, z[q][1]);
			expr.addTerm(1, devminus[q]);
			expr.addTerm(-1, devplus[q]);
			cplex.addEq(expr, 0);
		}
		// Ensure only one deviation takes value
		for (int q = 0; q <data.numSim; q++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			IloLinearNumExpr exprB = cplex.linearNumExpr();
			expr.addTerm(1, devminus[q]);
			expr.addTerm(-data.M[q], y[q]);
			cplex.addLe(expr, 0);

			exprB.addTerm(1, devplus[q]);
			exprB.addTerm(data.M[q], y[q]);
			cplex.addLe(exprB, data.M[q]);
		}

		// Symmetry breaking: only for the first simulation we can impose this!!!
			IloLinearNumExpr exprS = cplex.linearNumExpr();
			for (int i = 0; i <data.numItems; i++) {
				exprS.addTerm(data.sim[i][0], x[i][0]);
				exprS.addTerm(-data.sim[i][0], x[i][1]);
			}
			cplex.addGe(exprS, 0);

		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for (int q = 0; q < data.numSim; q++) {
			obj.addTerm(0.5, z[q][0]);
			obj.addTerm(0.5, z[q][1]);
			obj.addTerm(0.5, devminus[q]);
			obj.addTerm(0.5, devplus[q]);
		}

		cplex.addMaximize(obj,"maxProfit");
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Simulation Optimization is infeasible!");
			zsim = -1;
		}
		else{
			// Get solution
			zsim = cplex.getObjValue()/data.numSim;
			for (int j = 0; j <data.numBins; j++) {
				expectedVals[j] = 0;
				for (int i = 0; i < data.numItems; i++) {
					if(cplex.getValue(x[i][j])>0.1) {
						this.x[i][j]=1;
						expectedVals[j] += data.mu[i];
					}
				}

			}
			// Use the exact monster evaluation
			zsimREAL = solveSubproblem(data , null);
			System.out.println("SIMULATION OPTI SOLVED WITH "+data.numSim+" SIMULATIONS");
			System.out.println("OPTIMAL SIMULATED OBJ:"+zsim+" REAL MONSTER EVAL: "+zsimREAL);
			printSolSim(data);			

			//for (int q = 0; q < data.numSim; q++) {
			//	System.out.println("EV 1: "+cplex.getValue(z[q][0])+" EV 2: "+cplex.getValue(z[q][1])+"DEV PLUS "+cplex.getValue(devplus[q])+" DEV MINUS: "+cplex.getValue(devminus[q]));
			//}

		}


	}

	
	
}
