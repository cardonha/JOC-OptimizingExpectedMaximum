package OptimalKEntries;

import ilog.concert.IloException;
import ilog.concert.IloLinearNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;
import ilog.cplex.IloCplex.IntegerFeasibilityStatus;

import java.io.PrintStream;
import java.util.Random;

public class Callback extends IloCplex.LazyConstraintCallback {
	
	AlgorithmHandler alg;
	DataHandler data;
	IloNumVar[][] x;
	IloNumVar thetaS;
	IloNumVar theta;
	IloNumVar mu1;
	IloNumVar mu2;
	IloNumVar terms12;
	IloNumVar term3;
	IloCplex cplex;
	IloNumVar[] w;
	IloNumVar[] y;
	PrintStream ps;
	
 public Callback(IloNumVar[][] _x,IloNumVar ts, IloNumVar t, IloNumVar m1, IloNumVar m2, IloNumVar t12, IloNumVar t3, IloNumVar[] _w, IloNumVar[] _y, AlgorithmHandler a, DataHandler d, PrintStream PS, IloCplex _cplex) {
		  cplex = _cplex;
		  alg = a;
		  data = d;
		  x = _x;
		  thetaS = ts;
		  theta = t;
		  mu1 = m1;
		  mu2 = m2;
		  terms12 = t12;
		  term3 = t3;
		  w = _w;
		  y = _y;
		  ps = PS;
	  }

	  protected void main() throws IloException {
		  
  		  for (int k = 0; k < 2; k++) {
			  for (int j = 0; j <data.numItems; j++) {
				  alg.x[j][k] = (int)Math.round(getValue(x[j][k]));
			  }
		  }

/*		for (int i = 0; i < w.length; i++) {
			if(getValue(w[i])>0.1) {System.out.println("           W_"+i+"=1 INTERVAL: "+alg.intervalLimits1[i]);}
		}
		for (int i = 0; i < y.length; i++) {
			if(getValue(y[i])>0.1) {System.out.println("           Y_"+i+"=1 mu1-mu2: "+(getValue(mu1)-getValue(mu2))+" INTERVAL: "+alg.intervalLimits2[i]);}
		}
*/		
//		System.out.println("WEPA INSIDE CALLBACK BEFORE SUBPROBLEM");
		double realObj = alg.solveSubproblem(data , ps);
		double e = ( getValue(terms12)+getValue(term3)  - realObj)/realObj;
		System.out.println("FAKE OBJ: "+( getValue(terms12)+getValue(term3) ) + " REAL OBJ "+realObj+" Error: "+e);
		
		alg.error+= e;
		alg.errorCount++;

//		System.out.println("WEPA INSIDE CALLBACK ATER SUBPROBLEM");
	    
		// Add no-good cut 1 
		int rhs = 0;
		IloLinearNumExpr expr = cplex.linearNumExpr();
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numItems; j++) {
				if(alg.x[j][k]==1) {
					expr.addTerm(1, x[j][k]);
					rhs++;
				}
				else {
					expr.addTerm(-1, x[j][k]);
				}
			}
		}
		IloRange cut = cplex.le(expr, rhs-1);
		add(cut);
		alg.numCuts++;

		// Add no-good cut 2 (mirror!) 
		IloLinearNumExpr expr2 = cplex.linearNumExpr();
		for (int j = 0; j <data.numItems; j++) {
			if(alg.x[j][0]==1) {
				expr2.addTerm(1, x[j][1]);
			}
			else {
				expr2.addTerm(-1, x[j][1]);
			}
			if(alg.x[j][1]==1) {
				expr2.addTerm(1, x[j][0]);
			}
			else {
				expr2.addTerm(-1, x[j][0]);
			}
		}
		IloRange cut2 = cplex.le(expr2, rhs-1);
		add(cut2);
		alg.numCuts++;
		
//		if(alg.UB-getBestObjValue()>=0.1) {
//			ps.println(((System.nanoTime()-alg.Atime)/1000000000)+" "+alg.zstar+" "+alg.zsingle+" "+alg.mu1Star+" "+alg.mu2Star+" "+alg.LB+" "+getBestObjValue()+" "+alg.numCuts);
//		}

			
		alg.UB = getBestObjValue();
		alg.iterations++;
		if((alg.UB-alg.LB)/alg.UB<0.001) {
			System.out.println("******OPTIMAL CERTIFICATE******NumCuts: "+alg.numCuts+" LB: "+alg.LB+" UB: "+alg.UB);
			alg.optimalFound = true;
			abort();
			alg.printSolStar(data);
		}
			
		if(alg.iterations%1 == 0)
		System.out.println("**********************************************NumCuts: "+alg.numCuts+" LB: "+alg.LB+" UB: "+alg.UB);
   		       
	  }
	
}

