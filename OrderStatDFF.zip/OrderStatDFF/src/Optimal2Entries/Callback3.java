package Optimal2Entries;

import ilog.concert.IloException;
import ilog.concert.IloLinearNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;
import ilog.cplex.IloCplex.IntegerFeasibilityStatus;

import java.io.PrintStream;
import java.util.Random;

// For the heuristic !!!!
public class Callback3 extends IloCplex.LazyConstraintCallback {
	
	AlgorithmHandler alg;
	DataHandler data;
	IloNumVar[][] x;
	IloCplex cplex;
	PrintStream ps;
	
 public Callback3(IloNumVar[][] _x, AlgorithmHandler a, DataHandler d, PrintStream PS, IloCplex _cplex) {
		  cplex = _cplex;
		  alg = a;
		  data = d;
		  x = _x;
		  ps = PS;
	  }

	  protected void main() throws IloException {

		  for (int k = 0; k < 2; k++) {
			  for (int j = 0; j <data.numPlayers; j++) {
				  alg.x[j][k] = (int)Math.round(getValue(x[j][k]));
			  }
		  }

		//System.out.println("Ready to cut a Solution");
		alg.solveSubproblem(data, ps);
	    
			// Add no-good cut 1 
			int rhs = 0;
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numPlayers; j++) {
					if(alg.x[j][k]==1) {
						expr.addTerm(1, x[j][k]);
						rhs++;
					}
				}
			}
			IloRange cut = cplex.le(expr, rhs-1);
			add(cut);
			//alg.numCuts++;

			// Add no-good cut 2 (mirror!) 
			IloLinearNumExpr expr2 = cplex.linearNumExpr();
			for (int j = 0; j <data.numPlayers; j++) {
				if(alg.x[j][0]==1) {
					expr2.addTerm(1, x[j][1]);
				}
				if(alg.x[j][1]==1) {
					expr2.addTerm(1, x[j][0]);
				}
			}
			IloRange cut2 = cplex.le(expr2, rhs-1);
			add(cut2);
   		       
	  }
	
}

