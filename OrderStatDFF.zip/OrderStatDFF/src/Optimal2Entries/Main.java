/**
 * This is the main class for the cutting-plane algorithm.
 * 
 * Ref.: Bergman, Cardonha, Lozano, Imbrogno (2018). 
 * 
 * 
 * @author L. Lozano
 * @affiliation University of Cincinnati
 * 
 */
package Optimal2Entries;

import ilog.concert.IloException;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

public class Main {

	public static void main(String[] args) throws IOException, InterruptedException, IloException, InvalidFormatException {
	
		
		// Use this method to run the two-entry problem.
		//Receives a time limit in seconds.
		//runTwoEntry(args[0] , input_values[1]);
		String[] files = {"20181022-NYGATL-GameData-v3","20181101-OAKSF-GameData-v4","20181108-CARPIT-GameData-v3","20181112-NYGSF-GameData-v3","20181115-GBSEA-GameData-v5","20181118-PITJAX-GameData-v3","20181122-ATLNO-GameData-v3","20181203-WASPHI-GameData-v3","20181206-JAXTEN-GameData-v2","20181008-NOWAS-GameData-v1","20181004-INDNE-GameData-v3","20181001-DENKC-GameData-v1","20180930-BALPIT-GameData-v2","20180927-MINLAR-GameData-v2","20180923-SEADAL-GameData-v3","20180920-NYJCLE-GameData-v2"};
		for (int i = 0; i <= 15; i++) {
			//runTwoEntryOPTIMAL(files[i] , 600);
			runTwoEntryHEURISTIC(files[i]);
		}
		

	}

	
	private static void runTwoEntryOPTIMAL(String dataFile , double tLimit) throws IOException, InterruptedException, IloException, InvalidFormatException {

		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream("Results_"+dataFile+"_"+tLimit+".txt"));

		// Read a config file with the instance information: Num discrete points for linearization
		DataHandler data = new DataHandler(50, 10);
		data.readInstanceXLSX(dataFile, "v2");  
		data.muLimit = 3; // Limit for bad players, -1 means no limit

		// Create an AlgorithmHandler
		AlgorithmHandler alg = new AlgorithmHandler(data);

		// Begin the time count						
		alg.Atime = System.nanoTime();
		alg.solveSingleEntry(data, ps);
		alg.Heuristic2(data, ps);
		alg.genDiscretization(data);
		alg.BranchCut4(data , tLimit, ps);

		System.out.println("            EXECUTION TIME: "+((System.nanoTime()-alg.Atime)/1000000000));
		ps.println(((System.nanoTime()-alg.Atime)/1000000000)+" "+alg.zstar+" "+alg.zsingle+" "+alg.mu1Star+" "+alg.mu2Star+" "+alg.real1Star+" "+alg.real2Star+" "+alg.LB+" "+alg.UB+" "+alg.numCuts);
		//ps.println("REAL SCORES: "+alg.real1Star+" "+alg.real2Star);
	
		alg.cplex.clearModel();
		alg.cplex.end();
		System.gc();

	}
	private static void runTwoEntryHEURISTIC(String dataFile) throws IOException, InterruptedException, IloException, InvalidFormatException {

		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream("Results_"+dataFile+"_"+".txt"));

		// Read a config file with the instance information: Num discrete points for linearization
		DataHandler data = new DataHandler(0, 0);
		data.readInstanceXLSX(dataFile, "v3"); //false for Covariance 1, True for Covariance 2 
		data.muLimit = -1; // No limit for bad players

		// Create an AlgorithmHandler
		AlgorithmHandler alg = new AlgorithmHandler(data);

		// Begin the time count						
		alg.Atime = System.nanoTime();
		alg.HeuristicStandAlone(data, ps);

		System.out.println("            EXECUTION TIME: "+((System.nanoTime()-alg.Atime)/1000000000));
		ps.println(((System.nanoTime()-alg.Atime)/1000000000)+alg.mu1Star+" "+alg.mu2Star+" "+alg.real1Star+" "+alg.real2Star);
		alg.cplex.clearModel();
		alg.cplex.end();
		System.gc();

	}

	
}