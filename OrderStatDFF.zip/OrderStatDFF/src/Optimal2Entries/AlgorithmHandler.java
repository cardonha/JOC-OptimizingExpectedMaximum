/**
 * This class holds all the logic and procedures for hitting a monkey in the face.
 * 
 * Ref.: Lozano, L. and Smith, J. C. (2015). 
 * A Sampling-Based Exact Approach for the Bilevel Mixed Integer Programming Problem
 * 
 * @author L. Lozano & J. C. Smith
 * @affiliation Clemson University
 * @url www.leo-loza.com
 * 
 */

package Optimal2Entries;

import ilog.concert.*;
import ilog.cplex.*;
import ilog.cplex.IloCplex.UnknownObjectException;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Random;

import javax.crypto.spec.GCMParameterSpec;


public class AlgorithmHandler {

	
	int[][] x;						// Current solution
	double mu1;						// Current mu1
	double mu2;						// Current mu2
	double rho; 					// Current rho

	double zproxy;					// current z value from the master problem
	double Atime;
	
	double UB;						// Current UB
	double LB;						// Current LB
	
	int[][] xstar;					 // Optimal first-stage solution
	double mu1Star;					// Optimal mu1
	double mu2Star;					// Optimal mu2
	double rhoStar; 				// Optimal rho
	
	double real1Star;					// Optimal mu1
	double real2Star;					// Optimal mu2

	
	int[][] ystar;					// Optimal second-stage solutions
	double zstar;					// Optimal objective value
	
	int numCuts;						// Number of benders cuts
 	int iterations;						// Number of solutions explored

 	double zsingle;					// Optimal value for the single entry problem
 	double zheuristic;				// Value obtained with the heuristic

 	double maxThetaSquared;			// Upper bound on theta squared
 	double maxTheta;				// Upper bound on theta
 	double maxDelta;				// Upper bound on delta
	
	// Discrete values for theta squared
	double[] intervalLimits1;
	
	// Discrete values for delta(x)
	double[] intervalLimits2;

	// minimum that thetaS could be for each interval
	double[] minThetaS;

	
 	boolean optimalFound;			// Flag
 	
 	int numMoney;					// How many would win money
 	
 	double[] optSim; 				// Optimal value for each simulation
 	
	IloCplex cplex;							// Cplex model 1

	Random gR; 								// Global random stream
	
	public AlgorithmHandler(DataHandler data) throws InterruptedException, IloException {
		
		numCuts = 0;

		zproxy = Double.POSITIVE_INFINITY;
	
		x = new int[data.numPlayers][data.numEntries];
		xstar = new int[data.numPlayers][data.numEntries];
		
		zsingle = 0;
		UB = Double.POSITIVE_INFINITY;
		LB = -Double.POSITIVE_INFINITY;
		optimalFound = false;

		cplex = new IloCplex();
		
	    gR = new Random(0);



	}

	public void solveSingleEntry(DataHandler data, PrintStream ps) throws UnknownObjectException, IloException {
		
		//cplex.setParam(IloCplex.DoubleParam.TiLim, 3600);
		cplex.setOut(null);
		//cplex.setParam(IloCplex.DoubleParam.EpGap, 10E-14);
		
		IloNumVar[] x = new IloNumVar[data.numPlayers];

		//Create variables 

		for (int j = 0; j <data.numPlayers; j++) {
			x[j] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}
	
		//Add knapsack constraint
		IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
		for (int j = 0; j <data.numPlayers; j++) {
			budgetExpr.addTerm(data.pCost[j], x[j]);
		}
		cplex.addLe(budgetExpr, data.budget);

		//Select 5 Flex
		IloLinearNumExpr flexExpr = cplex.linearNumExpr();
		for (int j = 0; j <data.n; j++) {
			flexExpr.addTerm(1, x[j]);
		}
		cplex.addEq(flexExpr, 5);

		//Select 1 Cap
		IloLinearNumExpr capExpr = cplex.linearNumExpr();
		for (int j = data.n; j <2*data.n; j++) {
			capExpr.addTerm(1, x[j]);
		}
		cplex.addEq(capExpr, 1);
		
		//Select each player only once
		for (int j = 0; j <data.n; j++) {
			IloLinearNumExpr pExpr = cplex.linearNumExpr();
			pExpr.addTerm(1, x[j]);
			pExpr.addTerm(1, x[j+data.n]);
			cplex.addLe(pExpr, 1);
		}
		
		//Select at least one player from each team 
		IloLinearNumExpr t1Expr = cplex.linearNumExpr();
		IloLinearNumExpr t2Expr = cplex.linearNumExpr();
		for (int j = 0; j <data.numPlayers; j++) {
			if(data.team[j].equals(data.team1)) {t1Expr.addTerm(1, x[j]);}
			else {t2Expr.addTerm(1, x[j]);}
		}
		cplex.addGe(t1Expr, 1);
		cplex.addGe(t2Expr, 1);

		
		// ADD OBJECTIVE FUNCTION	
	      IloLinearNumExpr obj = cplex.linearNumExpr();
	      for (int j = 0; j < data.numPlayers; j++) {
	          obj.addTerm(data.mu[j],x[j]);
	      }
	  	  
	      cplex.addMaximize(obj,"Points");
	      cplex.solve();
  	  
		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Single entry is infeasible!");		
		}
		else{
			zsingle = cplex.getObjValue();
		    LB = cplex.getObjValue();
		    System.out.println("SINGLE ENTRY SOLVED: "+zsingle);
			for (int j = 0; j < data.numPlayers; j++) {
				if(cplex.getValue(x[j])>0.1) {this.x[j][0]=1;}
			}
			//solveSubproblem(data , ps);
			//printSolSingleEntry(data);
		}
		cplex.clearModel();	
		cplex.end();
		System.gc();
	}

public void printSolStar(DataHandler data) {
		System.out.println();
		System.out.println("Zstar (monster eval) = "+LB);
		System.out.println("Mu1: "+mu1Star+" Mu2: "+mu2Star+" Rho: "+rhoStar);
		
		double real1=0;
		double real2=0;
		for (int i = 0; i < 2*data.n; i++) {
			if(xstar[i][0]>0){
				real1+=data.realPoints[i];
			}
			if(xstar[i][1]>0){
				real2+=data.realPoints[i];
			}
		}
		
		System.out.println("Real Score 1: "+real1+" Real Score 2: "+real2);
		real1Star = real1;
		real2Star = real2;
		
		System.out.println("*****First entry:");
		for (int i = data.n; i < 2*data.n; i++) {
			if(xstar[i][0]>0){System.out.println(" CAPTAIN "+data.names[i]+" "+data.team[i]+" "+data.pos[i]);}
		}
		for (int i = 0; i < data.n; i++) {
			if(xstar[i][0]>0){System.out.println(" FLEX "+data.names[i]+" "+data.team[i]+" "+data.pos[i]);}
		}
		System.out.println();
		System.out.println("*****Second entry:");		
		for (int i = data.n; i < 2*data.n; i++) {
			if(xstar[i][1]>0){System.out.println(" CAPTAIN "+data.names[i]+" "+data.team[i]+" "+data.pos[i]);}
		}
		for (int i = 0; i < data.n; i++) {
			if(xstar[i][1]>0){System.out.println(" FLEX "+data.names[i]+" "+data.team[i]+" "+data.pos[i]);}
		}
	}
	
	public void printSol(DataHandler data, double lb) {
		System.out.println();
		System.out.println("Zstar (monster eval) = "+lb);
		double real1=0;
		double real2=0;
		for (int i = 0; i < 2*data.n; i++) {
			if(x[i][0]>0){
				real1+=data.realPoints[i];
			}
			if(x[i][1]>0){
				real2+=data.realPoints[i];
			}
		}
		
		System.out.println("Real Score 1: "+real1+" Real Score 2: "+real2);
		System.out.println("*****First entry:");
		for (int i = 0; i < data.numPlayers; i++) {
			if(x[i][0]>0){System.out.println(" Player selected "+i);}
		}
		System.out.println();
		System.out.println("*****Second entry:");		
		for (int i = 0; i < data.numPlayers; i++) {
			if(x[i][1]>0){System.out.println(" Player selected "+i);}
		}
		System.out.println();
	}
	public void printSolSingleEntry(DataHandler data) {
		//Calc mu and real
		double singleMu=0;
		double singleReal=0;
		
		for (int i = 0; i < 2*data.n; i++) {
			if(x[i][0]>0){
				singleMu+=data.mu[i];
				singleReal+=data.realPoints[i];
			}
		}
		System.out.println("Mu: "+singleMu);
		System.out.println("RealScore: "+singleReal);
		System.out.println("*****First entry:");
		for (int i = data.n; i < 2*data.n; i++) {
			if(x[i][0]>0){System.out.println(" CAPTAIN "+data.names[i]+" "+data.team[i]+" "+data.pCost[i]);}
		}

		for (int i = 0; i < data.n; i++) {
			if(x[i][0]>0){System.out.println(" FLEX "+data.names[i]+" "+data.team[i]+" "+data.pCost[i]);}
		}
		System.out.println();
	}
	
	public double solveSubproblem(DataHandler data, PrintStream ps) {
			boolean improvesLB = false;
			// Calculate real monster!!!!

			double mu1 = getmu1(data);
			double mu2 = getmu2(data);
			double theta = gettheta(data); 
			double lb = 0;
			this.mu1 = mu1;
			this.mu2 = mu2;
			
			Gaussian normal = new Gaussian();

			//System.out.println("    GOT HERE "+theta);
					
			if(theta==0) {
				lb = mu1;
			}
			else {
				//System.out.println("WEPAAAAAAAAAAA 2 THETA "+theta);
				
				lb = mu1*normal.cdf((mu1-mu2)/theta)+mu2*normal.cdf((mu2-mu1)/theta)+theta*normal.pdf((mu1-mu2)/theta);

				//System.out.println("LB:"+lb+"Real Mu1 "+mu1+" Mu2: "+mu2+" ThetaSquared: "+(theta*theta)+" Theta: "+theta+" cdf1: "+normal.cdf((mu1-mu2)/theta)+" cdf2: "+normal.cdf((mu2-mu1)/theta)+" pdf: "+normal.pdf((mu1-mu2)/theta));
			}
//			System.out.println("    GOT HERE");

//			printSol(data, lb);
			
			if(lb>=LB) {
				LB = lb;
				improvesLB = true;
				for (int i = 0; i < data.numPlayers; i++) {
					xstar[i][0]=x[i][0];
					xstar[i][1]=x[i][1];
				}
				mu1Star = this.mu1;
				mu2Star = this.mu2;
				rhoStar = rho;
				ps.println(((System.nanoTime()-Atime)/1000000000)+" "+zstar+" "+zsingle+" "+mu1Star+" "+mu2Star+" "+LB+" "+UB+" "+numCuts);
				
				//printSol(data, lb);
				//System.out.println("***********"+mu1+" "+mu2);
			}
			return lb;
	}

	
	private double gettheta(DataHandler data) {
		double theta = 0;
		double var1=0;
		double var2=0;
		double std1=0;
		double std2=0;
		double rho =0;
		double sumCov = 0;
		// Get variance
		for (int j = 0; j < data.numPlayers; j++) {
			var1+=data.var[j]*x[j][0];
			var2+=data.var[j]*x[j][1];
		}
		for (int j = 0; j < data.numPlayers; j++) {
			for (int q = 0; q < data.numPlayers; q++) {
				if(j!=q) {
				var1+=data.cov[j][q]*x[j][0]*x[q][0];
				var2+=data.cov[j][q]*x[j][1]*x[q][1];
				}
			}
		}
		// Get standard dev
		std1 = Math.sqrt(var1);
		std2 = Math.sqrt(var2);
		// Get sum of cov
		for (int j = 0; j < data.numPlayers; j++) {
			for (int q = 0; q < data.numPlayers; q++) {
				sumCov+=data.cov[j][q]*x[j][0]*x[q][1];
			}
		}
		
		// Get correlation
		double aux = Math.sqrt(var1*var2);
		rho = sumCov/aux;
		if(aux==0) {rho=1;}
		this.rho = rho;
//		System.out.println("Var1: "+var1+" var2: "+var2+" std1: "+std1+" std2: "+std2+" Cov: "+sumCov+" rho: "+rho+" aux: "+aux);
//		System.out.println("EY: "+(var1+var2-2*rho*std1*std2));
		theta = Math.sqrt(Math.max(var1+var2-2*rho*std1*std2 , 0));
		return theta;
	}

	private double getmu2(DataHandler data) {
		double mu = 0;
		
		for (int j = 0; j < data.numPlayers; j++) {
			mu+=data.mu[j]*x[j][1];
		}
		
	return mu;
	}

	private double getmu1(DataHandler data) {
		double mu = 0;
		
			for (int j = 0; j < data.numPlayers; j++) {
				mu+=data.mu[j]*x[j][0];
			}
			
		return mu;
	}

	public void Heuristic(DataHandler data, PrintStream ps) throws IloException {

		cplex = new IloCplex();
		cplex.setOut(null);
		cplex.setParam(IloCplex.DoubleParam.TiLim, 60);
		// Upper estimation
		IloNumVar mu1 = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float); // Max between mu1 and mu2
		IloNumVar mu2 = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float); // Min between mu1 and mu2
		IloNumVar[][] x = new IloNumVar[data.numPlayers][2];

		//Create variables 

		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numPlayers; j++) {
				if(data.mu[j]>=data.muLimit) {x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
				else {x[j][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
			}
		}
		//Add entry constraints
		for (int k = 0; k < 2; k++) {
			// Budget
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.numPlayers; j++) {
				budgetExpr.addTerm(data.pCost[j], x[j][k]);
			}
			cplex.addLe(budgetExpr, data.budget);
			
			//Select 5 Flex
			IloLinearNumExpr flexExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.n; j++) {
				flexExpr.addTerm(1, x[j][k]);
			}
			cplex.addEq(flexExpr, 5);

			//Select 1 Cap
			IloLinearNumExpr capExpr = cplex.linearNumExpr();
			for (int j = data.n; j <2*data.n; j++) {
				capExpr.addTerm(1, x[j][k]);
			}
			cplex.addEq(capExpr, 1);
			
			//Select each player only once
			for (int j = 0; j <data.n; j++) {
				IloLinearNumExpr pExpr = cplex.linearNumExpr();
				pExpr.addTerm(1, x[j][k]);
				pExpr.addTerm(1, x[j+data.n][k]);
				cplex.addLe(pExpr, 1);
			}
			
			//Select at least one player from each team 
			IloLinearNumExpr t1Expr = cplex.linearNumExpr();
			IloLinearNumExpr t2Expr = cplex.linearNumExpr();
			for (int j = 0; j <data.numPlayers; j++) {
				if(data.team[j].equals(data.team1)) {t1Expr.addTerm(1, x[j][k]);}
				else {t2Expr.addTerm(1, x[j][k]);}
			}
			cplex.addGe(t1Expr, 1);
			cplex.addGe(t2Expr, 1);
		}

		// Symmetry breaking
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int j = 0; j <data.numPlayers; j++) {
			exprS.addTerm(data.mu[j], x[j][0]);
			exprS.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addGe(exprS, 0);
		// Add max mu constraints
		IloLinearNumExpr expr = cplex.linearNumExpr();
		IloLinearNumExpr expr2 = cplex.linearNumExpr();
		for (int j = 0; j < data.numPlayers; j++) {
			expr.addTerm(data.mu[j], x[j][0]);
			expr2.addTerm(data.mu[j], x[j][1]);
		}
		expr.addTerm(-1, mu1);
		expr2.addTerm(-1, mu2);
		cplex.addEq(expr, 0);
		cplex.addEq(expr2, 0);	

		// ENFORCE DECENT TEAMS
		IloLinearNumExpr exprE = cplex.linearNumExpr();
		for (int j = 0; j < data.numPlayers; j++) {
			exprE.addTerm(data.mu[j], x[j][0]);
		}
		cplex.addGe(exprE, 0.95*zsingle);

		IloLinearNumExpr exprF = cplex.linearNumExpr();
		for (int j = 0; j < data.numPlayers; j++) {
			exprF.addTerm(data.mu[j], x[j][1]);
		}
		//cplex.addLe(exprF, 0.99*zsingle);
		cplex.addGe(exprF, 0.95*zsingle);
		
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1 , mu1);
		cplex.addMaximize(obj,"Points");

		cplex.use(new Callback3(x, this,data,ps,cplex));
		cplex.solve();

//		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
//			System.out.println("		HEURISTIC is infeasible!");		
//		}
		if(cplex.getStatus() != IloCplex.Status.Optimal ){

			System.out.println("HEURISTIC DONE!!!!!!!!!!!");
			System.out.println("OBJ HEURISTIC: "+LB);
			zheuristic = LB;
			cplex.clearModel();
			cplex.end();
			System.gc();
			printSolStar(data);
		}
		else{
			System.out.println("WEPAAAAAAAAA!");
			//	UB = cplex.getObjValue(); 
			/*	for (int k = 0; k < 2; k++) {
				for (int j = 0; j < data.numPlayers; j++) {
					if(cplex.getValue(x[j][k])>0.1)xstar[j][k]=1;
				}
			}

			printSolStar(data);
			 */	

		}


	}

	public void BranchCut4(DataHandler data , double timeLimit, PrintStream ps) throws IloException {
			cplex = new IloCplex();
			numCuts = 0;
			cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
			cplex.setParam(IloCplex.DoubleParam.CutLo, LB);
			cplex.setParam(IloCplex.DoubleParam.TiLim, timeLimit);

			//cplex.setOut(null);
			
			// Upper estimation
			IloNumVar thetaSquared = cplex.numVar(0, maxThetaSquared, IloNumVarType.Float);
			IloNumVar theta = cplex.numVar(0, maxTheta, IloNumVarType.Float);
			IloNumVar mu1 = cplex.numVar(0, zsingle, IloNumVarType.Float); // Max between mu1 and mu2
			IloNumVar mu2 = cplex.numVar(0, zsingle, IloNumVarType.Float); // Min between mu1 and mu2
			IloNumVar mu = cplex.numVar(0, zsingle, IloNumVarType.Float); // Combination between mu1 and mu2
			IloNumVar[][] x = new IloNumVar[data.numPlayers][2];

			// Linearization variables
			IloNumVar[][][] v = new IloNumVar[data.numPlayers][data.numPlayers][2];
			IloNumVar[][] r = new IloNumVar[data.numPlayers][data.numPlayers];
			
			// Discretization variables
			IloNumVar[] w = new IloNumVar[data.numPoints];
			IloNumVar[] y = new IloNumVar[data.numPointsD];
					
			//Create variables 
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numPlayers; j++) {
					if(data.mu[j]>=data.muLimit) {x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else {x[j][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numPlayers; j++) {
					for (int q = 0; q <data.numPlayers; q++) {
						if(j!=q && data.cov[j][q]!=0 && data.mu[j]>=data.muLimit && data.mu[q]>=data.muLimit) { v[j][q][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
						else { v[j][q][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
					}
				}
			}
			for (int j = 0; j <data.numPlayers; j++) {
				for (int q = 0; q <data.numPlayers; q++) {
					if(data.cov[j][q]!=0 && data.mu[j]>=data.muLimit && data.mu[q]>=data.muLimit) {r[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else {r[j][q] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
			for (int i = 0; i <data.numPoints; i++) {
				w[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
			for (int i = 0; i < data.numPointsD; i++) {
				y[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		
			//Add entry constraints
			for (int k = 0; k < 2; k++) {
				// Budget
				IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
				for (int j = 0; j <data.numPlayers; j++) {
					budgetExpr.addTerm(data.pCost[j], x[j][k]);
				}
				cplex.addLe(budgetExpr, data.budget);
				
				//Select 5 Flex
				IloLinearNumExpr flexExpr = cplex.linearNumExpr();
				for (int j = 0; j <data.n; j++) {
					flexExpr.addTerm(1, x[j][k]);
				}
				cplex.addEq(flexExpr, 5);

				//Select 1 Cap
				IloLinearNumExpr capExpr = cplex.linearNumExpr();
				for (int j = data.n; j <2*data.n; j++) {
					capExpr.addTerm(1, x[j][k]);
				}
				cplex.addEq(capExpr, 1);
				
				//Select each player only once
				for (int j = 0; j <data.n; j++) {
					IloLinearNumExpr pExpr = cplex.linearNumExpr();
					pExpr.addTerm(1, x[j][k]);
					pExpr.addTerm(1, x[j+data.n][k]);
					cplex.addLe(pExpr, 1);
				}
				
				//Select at least one player from each team 
				IloLinearNumExpr t1Expr = cplex.linearNumExpr();
				IloLinearNumExpr t2Expr = cplex.linearNumExpr();
				for (int j = 0; j <data.numPlayers; j++) {
					if(data.team[j].equals(data.team1)) {t1Expr.addTerm(1, x[j][k]);}
					else {t2Expr.addTerm(1, x[j][k]);}
				}
				cplex.addGe(t1Expr, 1);
				cplex.addGe(t2Expr, 1);
			}

			// Add linearization constraints I
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numPlayers; j++) {
					for (int q = 0; q <data.numPlayers; q++) {
						if(j!=q && data.cov[j][q]!=0) {
							if(data.cov[j][q]>0) {
								IloLinearNumExpr lExpr = cplex.linearNumExpr();
								lExpr.addTerm(1, v[j][q][k]);
								lExpr.addTerm(-1, x[j][k]);
								cplex.addLe(lExpr, 0);

								IloLinearNumExpr lExprb = cplex.linearNumExpr();
								lExprb.addTerm(1, v[j][q][k]);
								lExprb.addTerm(-1, x[q][k]);
								cplex.addLe(lExprb, 0);
							}
							else if(data.cov[j][q]<0) {
								IloLinearNumExpr lExprc = cplex.linearNumExpr();
								lExprc.addTerm(-1, v[j][q][k]);
								lExprc.addTerm(1, x[j][k]);
								lExprc.addTerm(1, x[q][k]);
								cplex.addLe(lExprc, 1);
							}
						}
					}
				}
			}
			// Add linearization constraints II
			for (int j = 0; j <data.numPlayers; j++) {
				for (int q = 0; q <data.numPlayers; q++) {
					if(data.cov[j][q]!=0) {
						if(data.cov[j][q]<0) {
							IloLinearNumExpr lExpr = cplex.linearNumExpr();
							lExpr.addTerm(1, r[j][q]);
							lExpr.addTerm(-1, x[j][0]);
							cplex.addLe(lExpr, 0);

							IloLinearNumExpr lExprb = cplex.linearNumExpr();
							lExprb.addTerm(1, r[j][q]);
							lExprb.addTerm(-1, x[q][1]);
							cplex.addLe(lExprb, 0);
						}
						else if(data.cov[j][q]>0) {
							IloLinearNumExpr lExprc = cplex.linearNumExpr();
							lExprc.addTerm(-1, r[j][q]);
							lExprc.addTerm(1, x[j][0]);
							lExprc.addTerm(1, x[q][1]);
							cplex.addLe(lExprc, 1);
						}
					}
				}
			}
			// Add Theta Squared constraint
			IloLinearNumExpr lExpr = cplex.linearNumExpr();
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numPlayers; j++) {
						lExpr.addTerm(data.var[j], x[j][k]);
						
					for (int q = 0; q <data.numPlayers; q++) {
						if(j!=q && data.cov[j][q]!=0) {
							lExpr.addTerm(data.cov[j][q], v[j][q][k]);
						}
					}
				}
			}
			for (int j = 0; j <data.numPlayers; j++) {
				for (int q = 0; q <data.numPlayers; q++) {
					if(data.cov[j][q]!=0) {
						lExpr.addTerm(-2*data.cov[j][q], r[j][q]);
					}
				}
			}
			lExpr.addTerm(-1, thetaSquared);
			cplex.addEq(lExpr, 0);
	
			// Add discretization constraints
			// theta = some image
			IloLinearNumExpr dExpr = cplex.linearNumExpr();
			for (int i = 0; i <data.numPoints-1; i++) {
					dExpr.addTerm(Math.sqrt(intervalLimits1[i+1]), w[i]);
			}
			dExpr.addTerm(-1, theta);
			cplex.addEq(dExpr, -1);
			// Sum of s_i = 1
			IloLinearNumExpr qExpr = cplex.linearNumExpr();
			for (int i = 0; i <data.numPoints; i++) {
					qExpr.addTerm(1, w[i]);
			}
			cplex.addEq(qExpr, 1);
			// w_q activation
			for (int i = 1; i < data.numPoints; i++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(intervalLimits1[i], w[i]);
				expr.addTerm(-1, thetaSquared);
				cplex.addLe(expr, 0);
			}
			// Symmetry breaking
			IloLinearNumExpr exprS = cplex.linearNumExpr();
			for (int j = 0; j <data.numPlayers; j++) {
					exprS.addTerm(data.mu[j], x[j][0]);
					exprS.addTerm(-data.mu[j], x[j][1]);
			}
			cplex.addGe(exprS, 0);
		
		// Add mu definition constraints
		IloLinearNumExpr expr = cplex.linearNumExpr();
		IloLinearNumExpr expr2 = cplex.linearNumExpr();
		for (int j = 0; j < data.numPlayers; j++) {
				expr.addTerm(data.mu[j], x[j][0]);
				expr2.addTerm(data.mu[j], x[j][1]);
		}
		expr.addTerm(-1, mu1);
		expr2.addTerm(-1, mu2);
		cplex.addEq(expr, 0);
		cplex.addEq(expr2, 0);	
		
		// Mu difference Discretization 
		// y_k activation 1
		for (int k = 0; k < data.numPointsD; k++) {
			IloLinearNumExpr expr3 = cplex.linearNumExpr();
			expr3.addTerm(1, mu1);
			expr3.addTerm(-1, mu2);
			expr3.addTerm(-intervalLimits2[k], y[k]);
			cplex.addGe(expr3, 0);
		}

		// y_k activation 2
		for (int k = 0; k < data.numPointsD-1; k++) {
			IloLinearNumExpr expr3 = cplex.linearNumExpr();
			expr3.addTerm(1, mu1);
			expr3.addTerm(-1, mu2);
			expr3.addTerm(-intervalLimits2[k+1], y[k]);
			expr3.addTerm(maxDelta, y[k]);
			cplex.addLe(expr3, maxDelta);
		}
		
		// Sum of y_k = 1
		IloLinearNumExpr kExpr = cplex.linearNumExpr();
		for (int k = 0; k <data.numPointsD; k++) {
				kExpr.addTerm(1, y[k]);
		}
		cplex.addEq(kExpr, 1);
		// Bounds for q=1,...,d
		Gaussian normal = new Gaussian();

		for (int q = 1; q < data.numPoints; q++) {
			for (int k = 0; k < data.numPointsD-1; k++) {
				IloLinearNumExpr expr3 = cplex.linearNumExpr();
				expr3.addTerm(-1, mu);
				double cdf = normal.cdf( (intervalLimits2[k+1]) / Math.sqrt(intervalLimits1[q]) );				
				expr3.addTerm(cdf, mu1);
				expr3.addTerm(1-cdf, mu2);
				expr3.addTerm(-zsingle, y[k]);
				expr3.addTerm(-zsingle, w[q]);
				//System.out.println("q: "+q+" k: "+k+" CDF: "+cdf);
				cplex.addGe(expr3, -2*zsingle);
			}
	
		}

		// Add final bound when w0=1
		IloLinearNumExpr expr3 = cplex.linearNumExpr();
		expr3.addTerm(-1, mu);
		expr3.addTerm(1, mu1);
		cplex.addGe(expr3, 0);
		
		// ADD super valid inequalities minTheta y_k <= thetaSQ
		for (int k = 0; k < data.numPointsD; k++) {
			IloLinearNumExpr expr4 = cplex.linearNumExpr();
			expr4.addTerm(1, thetaSquared);
			expr4.addTerm(-minThetaS[k], y[k]);
			cplex.addGe(expr4, 0);
		}

		// Add bound on delta(x)
		IloLinearNumExpr expr4 = cplex.linearNumExpr();
		expr3.addTerm(1, mu1);
		expr3.addTerm(-1, mu2);
		cplex.addLe(expr4, maxDelta);
		
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1 , mu);
		obj.addTerm(1/Math.sqrt(2*Math.PI) , theta);
		cplex.addMaximize(obj,"ExpectedScore");

		cplex.use(new Callback(x, thetaSquared, theta, mu1, mu2, mu, w, y, this,data, ps, cplex));
		cplex.solve();
		
			if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
				System.out.println("		B&C is infeasible after adding some cuts - OPTIMAL SOL FOUND");
				zstar = LB;
				UB = LB; 
				printSolStar(data);
			}
			else if(!optimalFound ){
     	        System.out.println("Stop early - TIME LIMIT");
 		        zstar = -1;
 		        UB = cplex.getBestObjValue();
 		        printSolStar(data);
			}
			else{
			zstar = LB;
			printSolStar(data);
			
	//			System.out.println("THETA SQUARED: "+cplex.getValue(thetaSquared)+" THETA: "+cplex.getValue(theta));
	//			for (int i = 0; i < data.numPoints; i++) {
	//				if(cplex.getValue(s[i])>0.1) System.out.println("s_"+i+" = 1");
	//			}			
			}
		}

	public void genDiscretization(DataHandler data) throws IloException {
		getMaxThetaS(data);		// Compute an upper bound on theta squared and theta
		genThetaLinPoints(data);
		getMaxDelta(data);		// Compute an upper bound on delta (x) and build the intervals
		
		// Get min theta
		minThetaS = new double[data.numPointsD];
		double step = (maxDelta)/(data.numPointsD-1);
		for (int i = 0; i < intervalLimits2.length; i++) {
			double minTheta = calcMinTheta(intervalLimits2[i]);
			minThetaS[i] = minTheta*minTheta;
	//		System.out.println("interval: "+intervalLimits2[i]+" MINTHETASQ: "+minThetaS[i]);		
		}
		
	/*	
		System.out.println("THETA INTERVALS: ");
		for (int i = 0; i < intervalLimits1.length; i++) {
			System.out.print(intervalLimits1[i]+" ");
		}
		System.out.println();

		System.out.println("DELTA INTERVALS: ");
		for (int i = 0; i < intervalLimits2.length; i++) {
			System.out.print(intervalLimits2[i]+" ");
		}
		System.out.println();
	*/	
	
		
	}

	
	private double calcMinTheta(double delta) {
		Gaussian normal = new Gaussian();
		double minT = 0.00000001;
		double obj = 0;

		while(obj < LB) {
			minT+=0.01;
			obj = zsingle+minT*normal.pdf((delta)/minT);
			//System.out.println("MIN T: "+minT+" OBJ: "+obj);
		}
		return minT-0.01;
	}
	private void genThetaLinPoints(DataHandler data) {
		// Gen Discretization points
		intervalLimits1 = new double[data.numPoints];
		
		double step = (maxThetaSquared)/(data.numPoints-1);
		for (int i = 0; i < data.numPoints; i++) {
			intervalLimits1[i] = 0+step*i;
		}

		
	}

	private void genDeltaLinPoints(DataHandler data) {
		// Gen Discretization points
		intervalLimits2 = new double[data.numPointsD];
		
		double step = (maxDelta)/(data.numPointsD-1);
		for (int i = 0; i < data.numPointsD; i++) {
			intervalLimits2[i] = 0+step*i;
		}

		
	}
	

	private void genDeltaLinPoints2(DataHandler data) {
		
		//Get max delta
		double minTheta = 0;
		double delta = 0;
		while (minTheta <= maxTheta) {
			minTheta = calcMinTheta(delta);
			System.out.println("DELTA: "+delta+" MINTHETA: "+minTheta);
			delta+=0.1;
		}
		maxDelta = delta;
		System.out.println("MAX DELTA "+delta);	
		
		// Gen Discretization points
		intervalLimits2 = new double[data.numPointsD];
		
		double step = (maxDelta)/(data.numPointsD-1);
		for (int i = 0; i < data.numPointsD; i++) {
			intervalLimits2[i] = 0+step*i;
		}

		
	}


	public void getMaxThetaS(DataHandler data) throws IloException {
			cplex = new IloCplex();
			cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
			cplex.setParam(IloCplex.DoubleParam.TiLim, 180);
			cplex.setOut(null);

			// Upper estimation
			IloNumVar thetaSquared = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float);
			IloNumVar[][] x = new IloNumVar[data.numPlayers][2];
			
			// Linearization variables
			IloNumVar[][][] v = new IloNumVar[data.numPlayers][data.numPlayers][2];
			IloNumVar[][] r = new IloNumVar[data.numPlayers][data.numPlayers];
					
			//Create variables 
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numPlayers; j++) {
					x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
				}
			}
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numPlayers; j++) {
					for (int q = 0; q <data.numPlayers; q++) {
						if(j!=q && data.cov[j][q]!=0) { v[j][q][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
						else { v[j][q][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
					}
				}
			}
			for (int j = 0; j <data.numPlayers; j++) {
				for (int q = 0; q <data.numPlayers; q++) {
					if(data.cov[j][q]!=0) {r[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else {r[j][q] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
			//Add entry constraints
			for (int k = 0; k < 2; k++) {
				// Budget
				IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
				for (int j = 0; j <data.numPlayers; j++) {
					budgetExpr.addTerm(data.pCost[j], x[j][k]);
				}
				cplex.addLe(budgetExpr, data.budget);
				
				//Select 5 Flex
				IloLinearNumExpr flexExpr = cplex.linearNumExpr();
				for (int j = 0; j <data.n; j++) {
					flexExpr.addTerm(1, x[j][k]);
				}
				cplex.addEq(flexExpr, 5);

				//Select 1 Cap
				IloLinearNumExpr capExpr = cplex.linearNumExpr();
				for (int j = data.n; j <2*data.n; j++) {
					capExpr.addTerm(1, x[j][k]);
				}
				cplex.addEq(capExpr, 1);
				
				//Select each player only once
				for (int j = 0; j <data.n; j++) {
					IloLinearNumExpr pExpr = cplex.linearNumExpr();
					pExpr.addTerm(1, x[j][k]);
					pExpr.addTerm(1, x[j+data.n][k]);
					cplex.addLe(pExpr, 1);
				}
				
				//Select at least one player from each team 
				IloLinearNumExpr t1Expr = cplex.linearNumExpr();
				IloLinearNumExpr t2Expr = cplex.linearNumExpr();
				for (int j = 0; j <data.numPlayers; j++) {
					if(data.team[j].equals(data.team1)) {t1Expr.addTerm(1, x[j][k]);}
					else {t2Expr.addTerm(1, x[j][k]);}
				}
				cplex.addGe(t1Expr, 1);
				cplex.addGe(t2Expr, 1);
			}

			// Add linearization constraints I
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numPlayers; j++) {
					for (int q = 0; q <data.numPlayers; q++) {
						if(j!=q && data.cov[j][q]!=0) {
							if(data.cov[j][q]>0) {
								IloLinearNumExpr lExpr = cplex.linearNumExpr();
								lExpr.addTerm(1, v[j][q][k]);
								lExpr.addTerm(-1, x[j][k]);
								cplex.addLe(lExpr, 0);
	
								IloLinearNumExpr lExprb = cplex.linearNumExpr();
								lExprb.addTerm(1, v[j][q][k]);
								lExprb.addTerm(-1, x[q][k]);
								cplex.addLe(lExprb, 0);
							}
							else if(data.cov[j][q]<0) {
								IloLinearNumExpr lExprc = cplex.linearNumExpr();
								lExprc.addTerm(-1, v[j][q][k]);
								lExprc.addTerm(1, x[j][k]);
								lExprc.addTerm(1, x[q][k]);
								cplex.addLe(lExprc, 1);
							}
						}
					}
				}
			}
			// Add linearization constraints II
			for (int j = 0; j <data.numPlayers; j++) {
				for (int q = 0; q <data.numPlayers; q++) {
					if(data.cov[j][q]!=0) {
						if(data.cov[j][q]<0) {
							IloLinearNumExpr lExpr = cplex.linearNumExpr();
							lExpr.addTerm(1, r[j][q]);
							lExpr.addTerm(-1, x[j][0]);
							cplex.addLe(lExpr, 0);
	
							IloLinearNumExpr lExprb = cplex.linearNumExpr();
							lExprb.addTerm(1, r[j][q]);
							lExprb.addTerm(-1, x[q][1]);
							cplex.addLe(lExprb, 0);
						}
						else if(data.cov[j][q]>0) {
							IloLinearNumExpr lExprc = cplex.linearNumExpr();
							lExprc.addTerm(-1, r[j][q]);
							lExprc.addTerm(1, x[j][0]);
							lExprc.addTerm(1, x[q][1]);
							cplex.addLe(lExprc, 1);
						}
					}
				}
			}
			// Add Theta Squared constraint
			IloLinearNumExpr lExpr = cplex.linearNumExpr();
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numPlayers; j++) {
						lExpr.addTerm(data.var[j], x[j][k]);
						
					for (int q = 0; q <data.numPlayers; q++) {
						if(j!=q && data.cov[j][q]!=0) {
							lExpr.addTerm(data.cov[j][q], v[j][q][k]);
						}
					}
				}
			}
			for (int j = 0; j <data.numPlayers; j++) {
				for (int q = 0; q <data.numPlayers; q++) {
					if(data.cov[j][q]!=0) {
						lExpr.addTerm(-2*data.cov[j][q], r[j][q]);
					}
				}
			}
			lExpr.addTerm(-1, thetaSquared);
			cplex.addEq(lExpr, 0);
			// Symmetry breaking
			IloLinearNumExpr exprS = cplex.linearNumExpr();
			for (int j = 0; j <data.numPlayers; j++) {
					exprS.addTerm(data.mu[j], x[j][0]);
					exprS.addTerm(-data.mu[j], x[j][1]);
			}
			cplex.addGe(exprS, 0);
	
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1, thetaSquared);
		cplex.addMaximize(obj,"ThetaSquared");
		cplex.solve();
		
			if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
				System.out.println("		Theta Bounder is infeasible!");		
			}
			else{
				maxThetaSquared = cplex.getBestObjValue();
				maxTheta = Math.sqrt(maxThetaSquared);
				System.out.println("MAX THETA SQUARED IS: "+maxThetaSquared+" MAX THETA: "+maxTheta);
				
				cplex.clearModel();
				cplex.end();
				System.gc();
			}
		}

	
	public void getMaxDelta(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
		cplex.setParam(IloCplex.DoubleParam.TiLim, 180);
		cplex.setOut(null);

		// Upper estimation
		IloNumVar thetaSquared = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float);
		IloNumVar[][] x = new IloNumVar[data.numPlayers][2];
		
		//Create variables 
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numPlayers; j++) {
				x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}

		//Add entry constraints
		for (int k = 0; k < 2; k++) {
			// Budget
			IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.numPlayers; j++) {
				budgetExpr.addTerm(data.pCost[j], x[j][k]);
			}
			cplex.addLe(budgetExpr, data.budget);
			
			//Select 5 Flex
			IloLinearNumExpr flexExpr = cplex.linearNumExpr();
			for (int j = 0; j <data.n; j++) {
				flexExpr.addTerm(1, x[j][k]);
			}
			cplex.addEq(flexExpr, 5);

			//Select 1 Cap
			IloLinearNumExpr capExpr = cplex.linearNumExpr();
			for (int j = data.n; j <2*data.n; j++) {
				capExpr.addTerm(1, x[j][k]);
			}
			cplex.addEq(capExpr, 1);
			
			//Select each player only once
			for (int j = 0; j <data.n; j++) {
				IloLinearNumExpr pExpr = cplex.linearNumExpr();
				pExpr.addTerm(1, x[j][k]);
				pExpr.addTerm(1, x[j+data.n][k]);
				cplex.addLe(pExpr, 1);
			}
			
			//Select at least one player from each team 
			IloLinearNumExpr t1Expr = cplex.linearNumExpr();
			IloLinearNumExpr t2Expr = cplex.linearNumExpr();
			for (int j = 0; j <data.numPlayers; j++) {
				if(data.team[j].equals(data.team1)) {t1Expr.addTerm(1, x[j][k]);}
				else {t2Expr.addTerm(1, x[j][k]);}
			}
			cplex.addGe(t1Expr, 1);
			cplex.addGe(t2Expr, 1);
		}

		// Symmetry breaking
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int j = 0; j <data.numPlayers; j++) {
				exprS.addTerm(data.mu[j], x[j][0]);
				exprS.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addGe(exprS, 0);

	// ADD OBJECTIVE FUNCTION	
	IloLinearNumExpr obj = cplex.linearNumExpr();
	for (int j = 0; j <data.numPlayers; j++) {
		obj.addTerm(data.mu[j], x[j][0]);
		obj.addTerm(-data.mu[j], x[j][1]);
	}
	cplex.addMaximize(obj,"Delta");
	cplex.solve();
	
		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		DELTA Bounder is infeasible!");		
		}
		else{
			maxDelta = cplex.getBestObjValue();
			System.out.println("MAX DELTA "+maxDelta);	
			
			// Gen Discretization points
			intervalLimits2 = new double[data.numPointsD];
			
			double step = (maxDelta)/(data.numPointsD-1);
			for (int i = 0; i < data.numPointsD; i++) {
				intervalLimits2[i] = 0+step*i;
			}

			cplex.clearModel();
			cplex.end();
			System.gc();
		}
	}

	public void Heuristic2(DataHandler data, PrintStream ps) throws IloException {
		
		ArrayList<int[]> pool = new ArrayList<int[]>(); 
		
		cplex = new IloCplex();
		cplex.setOut(null);
		
		IloNumVar[] x = new IloNumVar[data.numPlayers];

		//Create variables 

		for (int j = 0; j <data.numPlayers; j++) {
			if(data.mu[j]>=data.muLimit) {x[j] = cplex.numVar(0, 1, IloNumVarType.Bool);}
			else {x[j] = cplex.numVar(0, 0, IloNumVarType.Float);}
		}
	
		//Add knapsack constraint
		IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
		for (int j = 0; j <data.numPlayers; j++) {
			budgetExpr.addTerm(data.pCost[j], x[j]);
		}
		cplex.addLe(budgetExpr, data.budget);

		//Select 5 Flex
		IloLinearNumExpr flexExpr = cplex.linearNumExpr();
		for (int j = 0; j <data.n; j++) {
			flexExpr.addTerm(1, x[j]);
		}
		cplex.addEq(flexExpr, 5);

		//Select 1 Cap
		IloLinearNumExpr capExpr = cplex.linearNumExpr();
		for (int j = data.n; j <2*data.n; j++) {
			capExpr.addTerm(1, x[j]);
		}
		cplex.addEq(capExpr, 1);
		
		//Select each player only once
		for (int j = 0; j <data.n; j++) {
			IloLinearNumExpr pExpr = cplex.linearNumExpr();
			pExpr.addTerm(1, x[j]);
			pExpr.addTerm(1, x[j+data.n]);
			cplex.addLe(pExpr, 1);
		}
		
		//Select at least one player from each team 
		IloLinearNumExpr t1Expr = cplex.linearNumExpr();
		IloLinearNumExpr t2Expr = cplex.linearNumExpr();
		for (int j = 0; j <data.numPlayers; j++) {
			if(data.team[j].equals(data.team1)) {t1Expr.addTerm(1, x[j]);}
			else {t2Expr.addTerm(1, x[j]);}
		}
		cplex.addGe(t1Expr, 1);
		cplex.addGe(t2Expr, 1);

		
		// ADD OBJECTIVE FUNCTION	
	      IloLinearNumExpr obj = cplex.linearNumExpr();
	      for (int j = 0; j < data.numPlayers; j++) {
	          obj.addTerm(data.mu[j],x[j]);
	      }
	  	  
	      cplex.addMaximize(obj,"Points");
	    
	      for (int i = 0; i < 300; i++) {
	    	  cplex.solve();
	    	  
	    	  if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
	    		  System.out.println("		Heuristic: infeasible!");
	    		  i=9000000;
	    	  }
	    	  else{
	    		  
	    		  int[] sol = new int[data.numPlayers];
	    		  for (int j = 0; j < data.numPlayers; j++) {
	    			  if(cplex.getValue(x[j])>0.1) {sol[j]=1;}
	    		  }
	    		  pool.add(sol);
	    		  
	    		// Cut solution
  				IloLinearNumExpr cExpr = cplex.linearNumExpr();
  				int rhs =0;
	    		  for (int j = 0; j <data.numPlayers; j++) {
	    			  if(sol[j]==1) { 
	    				  cExpr.addTerm(1, x[j]);
	    				  rhs++;
	    			  }
	    			}
	    		 cplex.addLe(cExpr, rhs-2);  

	    		 
	    	/*	  for (int j = 0; j <data.numPlayers; j++) {
	    			  if(sol[j]==1) System.out.print(j+" ");
	    			}
	    		System.out.println("**************************************");
	    	*/	
	    	  }
	      }

		System.out.println("HEURISTIC DONE!!!!!!!!!!!");
		evalPool(data, pool, ps);
		System.out.println("OBJ HEURISTIC: "+LB);
		zheuristic = LB;
		cplex.clearModel();
		cplex.end();
		System.gc();
		printSolStar(data);
		
	}
	public void HeuristicStandAlone(DataHandler data, PrintStream ps) throws IloException {
		
		ArrayList<int[]> pool = new ArrayList<int[]>(); 
		
		cplex = new IloCplex();
		cplex.setOut(null);
		
		IloNumVar[] x = new IloNumVar[data.numPlayers];

		//Create variables 

		for (int j = 0; j <data.numPlayers; j++) {
			if(data.mu[j]>=data.muLimit) {x[j] = cplex.numVar(0, 1, IloNumVarType.Bool);}
			else {x[j] = cplex.numVar(0, 0, IloNumVarType.Float);}
		}
	
		//Add knapsack constraint
		IloLinearNumExpr budgetExpr = cplex.linearNumExpr();
		for (int j = 0; j <data.numPlayers; j++) {
			budgetExpr.addTerm(data.pCost[j], x[j]);
		}
		cplex.addLe(budgetExpr, data.budget);

		//Select 5 Flex
		IloLinearNumExpr flexExpr = cplex.linearNumExpr();
		for (int j = 0; j <data.n; j++) {
			flexExpr.addTerm(1, x[j]);
		}
		cplex.addEq(flexExpr, 5);

		//Select 1 Cap
		IloLinearNumExpr capExpr = cplex.linearNumExpr();
		for (int j = data.n; j <2*data.n; j++) {
			capExpr.addTerm(1, x[j]);
		}
		cplex.addEq(capExpr, 1);
		
		//Select each player only once
		for (int j = 0; j <data.n; j++) {
			IloLinearNumExpr pExpr = cplex.linearNumExpr();
			pExpr.addTerm(1, x[j]);
			pExpr.addTerm(1, x[j+data.n]);
			cplex.addLe(pExpr, 1);
		}
		
		//Select at least one player from each team 
		IloLinearNumExpr t1Expr = cplex.linearNumExpr();
		IloLinearNumExpr t2Expr = cplex.linearNumExpr();
		for (int j = 0; j <data.numPlayers; j++) {
			//System.out.println("WEPA: "+data.team[j]+"   WEPOTA: "+data.team1+" WEPITITA: "+data.team2);
			if(data.team[j].equals(data.team1)) {t1Expr.addTerm(1, x[j]);}
			else {t2Expr.addTerm(1, x[j]);}
		}
		cplex.addGe(t1Expr, 1);
		cplex.addGe(t2Expr, 1);

		
		// ADD OBJECTIVE FUNCTION	
	      IloLinearNumExpr obj = cplex.linearNumExpr();
	      for (int j = 0; j < data.numPlayers; j++) {
	          obj.addTerm(data.mu[j],x[j]);
	      }
	  	  
	      cplex.addMaximize(obj,"Points");
	    
	      for (int i = 0; i < 2; i++) {
	    	  cplex.solve();
	    	  
	    	  if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
	    		  System.out.println("		Heuristic STAND ALONE: infeasible!");
	    		  i=9000000;
	    	  }
	    	  else{
	    		  
	    		  int[] sol = new int[data.numPlayers];
	    		  for (int j = 0; j < data.numPlayers; j++) {
	    			  if(cplex.getValue(x[j])>0.1) {sol[j]=1;}
	    		  }
	    		  pool.add(sol);
	    		  
	    		// Cut solution
  				IloLinearNumExpr cExpr = cplex.linearNumExpr();
  				int rhs =0;
	    		  for (int j = 0; j <data.numPlayers; j++) {
	    			  if(sol[j]==1) { 
	    				  cExpr.addTerm(1, x[j]);
	    				  rhs++;
	    			  }
	    			}
	    		 cplex.addLe(cExpr, rhs-1);  

	    		 
	    	/*	  for (int j = 0; j <data.numPlayers; j++) {
	    			  if(sol[j]==1) System.out.print(j+" ");
	    			}
	    		System.out.println("**************************************");
	    	*/	
	    	  }
	    	  
	    	  

	      }

		System.out.println("HEURISTIC STAND ALONE DONE!!!!!!!!!!!");
		evalPool(data, pool, ps);
		printSolStar(data);
		
	}

	
	private void printRealScore(DataHandler data, int[] sol) {
		double realScore = 0;
		for (int i = 0; i < data.numPlayers; i++) {
			if(sol[i]>0){
				realScore+=data.realPoints[i];
			}
		}
		
		System.out.println("Real Score: "+realScore);
		
	}

	private void evalPool(DataHandler data, ArrayList<int[]> pool, PrintStream ps) {
		
		for (int i = 0; i <pool.size(); i++) {
			for (int j = i+1; j < pool.size(); j++) {
				
				for (int k = 0; k < data.numPlayers; k++) {
						x[k][0]=pool.get(i)[k];
						x[k][1]=pool.get(j)[k];
				}
				
				if(0==0 || checkCuts(data)==true) {solveSubproblem(data, ps);}
				
			}
		}
		

	}

	public boolean checkCuts(DataHandler data) {
		// check if QB is captain and there is also a DST in first entry
		for (int j = data.n; j <2*data.n; j++) {
			if(x[j][0]>=0.9 && data.pos[j].equals("QB")) {
				//System.out.println("YUP QB IS CAPTAIN");
				for (int i = 0; i < 2*data.n; i++) {
					if(x[i][0]>=0.9 && data.pos[i].equals("DST")) {
						//System.out.println("    YEAP ALSO A FLEX IS DST ");
						return false;
					}
				}
			}
		}
		// check if QB is captain and there is also a DST in second entry
		for (int j = data.n; j <2*data.n; j++) {
			if(x[j][1]>=0.9 && data.pos[j].equals("QB")) {
				//System.out.println("YUP QB IS CAPTAIN");
				for (int i = 0; i < 2*data.n; i++) {
					if(x[i][1]>=0.9 && data.pos[i].equals("DST")) {
						//System.out.println("    YEAP ALSO A FLEX IS DST ");
						return false;
					}
				}
			}
		}
		// check if WR is captain, then there should be QB from same team in first entry
		for (int j = data.n; j <2*data.n; j++) {
			if(x[j][0]>=0.9 && data.pos[j].equals("WR")) {
				//System.out.println("YUP WR IS CAPTAIN");
				int checkQB = 0;
				for (int i = 0; i < 2*data.n; i++) {
					if(x[i][0]>=0.9 && data.pos[i].equals("QB") && data.team[j].equals(data.team[i])) {
						//System.out.println("    Wepa there is QB from same team");
						checkQB++;
					}
				}
				if(checkQB==0) {return false;}
			}
		}
		// check if WR is captain, then there should be QB from same team in second entry
				for (int j = data.n; j <2*data.n; j++) {
					if(x[j][1]>=0.9 && data.pos[j].equals("WR")) {
						//System.out.println("YUP WR IS CAPTAIN");
						int checkQB = 0;
						for (int i = 0; i < 2*data.n; i++) {
							if(x[i][1]>=0.9 && data.pos[i].equals("QB") && data.team[j].equals(data.team[i])) {
								//System.out.println("    Wepa there is QB from same team");
								checkQB++;
							}
						}
						if(checkQB==0) {return false;}
					}
				}
		
		// check if TE is captain, then there should be QB from same team in first entry
				for (int j = data.n; j <2*data.n; j++) {
					if(x[j][0]>=0.9 && data.pos[j].equals("TE")) {
						//System.out.println("YUP TE IS CAPTAIN");
						int checkQB = 0;
						for (int i = 0; i < 2*data.n; i++) {
							if(x[i][0]>=0.9 && data.pos[i].equals("QB") && data.team[j].equals(data.team[i])) {
								//System.out.println("    Wepa there is QB from same team");
								checkQB++;
							}
						}
						if(checkQB==0) {return false;}
					}
				}		
		// check if TE is captain, then there should be QB from same team in second entry
				for (int j = data.n; j <2*data.n; j++) {
					if(x[j][1]>=0.9 && data.pos[j].equals("TE")) {
						//System.out.println("YUP TE IS CAPTAIN");
						int checkQB = 0;
						for (int i = 0; i < 2*data.n; i++) {
							if(x[i][1]>=0.9 && data.pos[i].equals("QB") && data.team[j].equals(data.team[i])) {
								//System.out.println("    Wepa there is QB from same team");
								checkQB++;
							}
						}
						if(checkQB==0) {return false;}
					}
				}		
		
		
		return true;
	}

	
	
}
