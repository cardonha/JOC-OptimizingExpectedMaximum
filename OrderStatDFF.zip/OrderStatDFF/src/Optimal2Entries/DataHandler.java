/**
 * This class holds all the data.
 * 
 * Ref.: Lozano, L. and Smith, J. C. (2015). 
 * A Sampling-Based Exact Approach for the Bilevel Mixed Integer Programming Problem
 * 
 * @author L. Lozano & J. C. Smith
 * @affiliation Clemson University
 * @url www.leo-loza.com
 * 
 */
package Optimal2Entries;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Random;
import java.util.StringTokenizer;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class DataHandler {
	// Number of players (total flex + caps)
	public int numPlayers;
	
	// Real number of players
	public int n;
	
	public int numEntries;

	// Budget constraint
	public double budget;
	
	// Player salary
	double[] pCost;
	
	// Expected points for a given player
	double[] mu;

	// Real points for a given player
	double[] realPoints;

	// Name for a given player
	String[] names;
	
	// Team for a given player
	String[] team;

	//Position for a given player
	String[] pos;

	
	// Variance for a given player
	double[] var;

	// Covariance for a pair of players
	double[][] cov;

	// number of discrete points to approx a sqrt
	int numPoints;

	// number of discrete points to approx delta(x
	int numPointsD;

	//Name of the teams
	String team1;
	String team2;
	
	double muLimit;

	// Read data from an instance
	public DataHandler(int nDiscrete, int nDis2) {
		numPoints = nDiscrete;
		numPointsD = nDis2;
		numEntries = 2;
		muLimit = 0;
				
	}
	public void readInstanceXLSX(String filename, String version) throws InvalidFormatException, IOException {
		
		   InputStream inp = new FileInputStream("dataNEW/"+filename+".xlsx");

		    Workbook wb = WorkbookFactory.create(inp);
		    // READ data
		    Sheet sheet = wb.getSheetAt(1);
		    // READ number of players
	    	Row prow = sheet.getRow(1);
	    	Cell pcell = prow.getCell(15);
	    	n = (int) pcell.getNumericCellValue();
		    numPlayers=2*n;
 		    // READ Budget
	    	Row brow = sheet.getRow(1);
	    	Cell bcell = brow.getCell(16);
	    	budget = bcell.getNumericCellValue();
	    	//Read team names
	    	Row trow = sheet.getRow(1);
	    	Cell tcell = trow.getCell(17);
	    	team1 = tcell.getStringCellValue();
	    	tcell = trow.getCell(18);
	    	team2 = tcell.getStringCellValue();
	    	
			//System.out.println("WEPAAAA num vars: "+numPlayers+" RHS: "+budget+"  "+team1+"  "+team2);
			
			// Initialize vectors
			pCost = new double[numPlayers];
			mu = new double[numPlayers];
			var  = new double[numPlayers];
			cov = new double[numPlayers][numPlayers];
			names = new String[numPlayers];
			pos = new String[numPlayers];
			realPoints = new double[numPlayers];
			team = new String[numPlayers];

	    	// READ player stats
		    for (int i = 1; i <= numPlayers; i++) {
		    	Row row = sheet.getRow(i);
		    	Cell cell = row.getCell(1);
		    	String name = cell.getStringCellValue();
		    	names[i-1] = name;
		    	cell = row.getCell(11);
		    	mu[i-1] = cell.getNumericCellValue();
		    	cell = row.getCell(6);
		    	pCost[i-1] = cell.getNumericCellValue();
		    	cell = row.getCell(13);
		    	realPoints[i-1] = cell.getNumericCellValue();
		    	cell = row.getCell(8);
		    	String t = cell.getStringCellValue();
		    	team[i-1] = t;
		    	cell = row.getCell(0);
		    	String p = cell.getStringCellValue();
		    	pos[i-1] = p;
		    	//System.out.println("PLAYER "+(i-1)+" "+names[i-1]+" "+mu[i-1]+" "+realPoints[i-1]+" "+pCost[i-1]+" "+team[i-1]+" "+pos[i-1]);
		    }

		    
		    // READ Covariance
		    if(version.equals("v1")) {sheet = wb.getSheetAt(3);}
		    if(version.equals("v2")) {sheet = wb.getSheetAt(4);}
		    if(version.equals("v3")) {sheet = wb.getSheetAt(2);}
		    
		    for (int i = 0; i < numPlayers; i++) {
		    	Row row = sheet.getRow(i);
		    	for (int j = 0; j < numPlayers; j++) {
		    		Cell cell = row.getCell(j);
		    		cov[i][j] = cell.getNumericCellValue();
		    		//System.out.print(cov[i][j]+" ");
		    	}
		    	var[i] = cov[i][i]; 
		    	//System.out.println();
		    }

			inp.close();
		    
		}



}

