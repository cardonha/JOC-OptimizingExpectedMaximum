/**
 * This class holds all the logic and procedures for hitting a monkey in the face.
 * 
 * Ref.: Lozano, L. and Smith, J. C. (2015). 
 * A Sampling-Based Exact Approach for the Bilevel Mixed Integer Programming Problem
 * 
 * @author L. Lozano & J. C. Smith
 * @affiliation Clemson University
 * @url www.leo-loza.com
 * 
 */

package OptimalKEntries;

import ilog.concert.*;
import ilog.cplex.*;
import ilog.cplex.IloCplex.UnknownObjectException;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Random;

import javax.crypto.spec.GCMParameterSpec;


public class AlgorithmHandler {

	
	int[][] x;						// Current solution
	double mu1;						// Current mu1
	double mu2;						// Current mu2
	double rho; 					// Current rho

	double zproxy;					// current z value from the master problem
	double Atime;
	
	double UB;						// Current UB
	double LB;						// Current LB
	
	int[][] xstar;					 // Optimal first-stage solution
	double mu1Star;					// Optimal mu1
	double mu2Star;					// Optimal mu2
	double rhoStar; 				// Optimal rho

	
	int[][] ystar;					// Optimal second-stage solutions
	double zstar;					// Optimal objective value
	
	int numCuts;						// Number of benders cuts
 	int iterations;						// Number of solutions explored

 	double zheuristic;					// Optimal value for the heuristic
 	double zheuristicREAL;				// Value obtained with the heuristic
 	double zsim;					// Estimated optimal value for the simulation opti
 	double zsimREAL;				// Real monster eval for the simulation opti
 	double variance;				// Variance for the oracle evaluations

 	double maxThetaSquared;			// Upper bound on theta squared
 	double maxTheta;				// Upper bound on theta
 	double maxDelta;				// Upper bound on delta
	
 	double error;					//Difference between UB and real obj in the exact two entry method
 	int errorCount;					//Number of solutions evaluated
	// Discrete values for theta squared
	double[] intervalLimits1;
	
	// Discrete values for delta(x)
	double[] intervalLimits2;

	// minimum that thetaS could be for each interval
	double[] minThetaS;

	
 	boolean optimalFound;			// Flag
 	
 	int numMoney;					// How many would win money
 	
 	double[] optSim; 				// Optimal value for each simulation
 	
	IloCplex cplex;							// Cplex model 1

	Random gR; 								// Global random stream
	
	public AlgorithmHandler(DataHandler data) throws InterruptedException, IloException {
		
		numCuts = 0;

		zproxy = Double.POSITIVE_INFINITY;
	
		x = new int[data.numJobs][data.numMachines];
		xstar = new int[data.numJobs][data.numMachines];
		
		UB = Double.POSITIVE_INFINITY;
		LB = -Double.POSITIVE_INFINITY;
		optimalFound = false;

		cplex = new IloCplex();
		
	    gR = new Random(0);
	    
	}

	public void solveHeuristic(DataHandler data) throws UnknownObjectException, IloException {
		
		cplex.setParam(IloCplex.DoubleParam.TiLim, 600);
		//cplex.setOut(null);
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
		
		IloNumVar[][] x = new IloNumVar[data.numJobs][data.numMachines];
		IloNumVar z = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float);

		//Create variables 
		for (int k = 0; k < data.numMachines; k++) {
			for (int j = 0; j <data.numJobs; j++) {
				x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}

		//Add Jobs constraint
			for (int j = 0; j <data.numJobs; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				for (int k = 0; k < data.numMachines; k++) {
					expr.addTerm(1, x[j][k]);
				}
				cplex.addEq(expr, 1);
			}
	
		// Add min max constraint
			for (int k = 0; k < data.numMachines; k++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(1, z);
				for (int j = 0; j <data.numJobs; j++) {
					expr.addTerm(-data.mu[j], x[j][k]);
				}
				cplex.addGe(expr, 0);
			}
		
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1,z);

		cplex.addMinimize(obj,"Makespan");
	          
			cplex.solve();
			
			if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
				System.out.println("		HEURISTIC is infeasible after adding some cuts");
			}
			else{
				zheuristic = cplex.getObjValue();
				System.out.println("FALSE MAKESPAN H : "+cplex.getObjValue());
				for (int k = 0; k < data.numMachines; k++) {
					for (int j = 0; j <data.numJobs; j++) {
						this.x[j][k] = (int) Math.round(cplex.getValue(x[j][k]));
					}
				}
			}

		if(data.numMachines==2) {
			zheuristicREAL = solveSubproblem(data, null);
	    	System.out.println("HEURISTIC MONSTER EVAL: "+zheuristicREAL);
		}
		
	}
	
// Function for calculating variance 
static double getVariance(double a[], int n) { 
    // Compute mean (average of elements) 
    double sum = 0; 
    for (int i = 0; i < n; i++) 
        sum += a[i]; 
    double mean = sum /n; 
    // Compute sum squared differences with mean. 
    double sqDiff = 0; 
    for (int i = 0; i < n; i++)  
        sqDiff += (a[i] - mean)*(a[i] - mean); 
      
    return (double)sqDiff / (n-1); 
} 

private void putSorted(double score, ArrayList<Double> sortedObj) {
	
	boolean inserted = false;
	for (int i = 0; i < sortedObj.size(); i++) {
		if(score<sortedObj.get(i)) {
			sortedObj.add(i, score);
			inserted=true;
			i = sortedObj.size()+10;
		}
	}
	if(inserted == false) {
		sortedObj.add(score);
	}
	
	
}



public void printSolStar(DataHandler data) {
		System.out.println();
		System.out.println("Zstar (monster eval) = "+UB);
		System.out.println("Mu1: "+mu1Star+" Mu2: "+mu2Star);
		System.out.println("*****First Machine:");
		for (int i = 0; i < data.numJobs; i++) {
			if(xstar[i][0]>0){System.out.println("Job assigned "+i);}
		}
		System.out.println();
		System.out.println("*****Second Machine:");		
		for (int i = 0; i < data.numJobs; i++) {
			if(xstar[i][1]>0){System.out.println("Job assigned "+i);}
		}
	}
	
	public void printSol(DataHandler data) {
		System.out.println("Zstar (monster eval) = "+LB);
		System.out.println("Mu1: "+mu1+" Mu2: "+mu2+" Rho: "+rho);
		System.out.println("*****First entry:");
		for (int i = 0; i < data.numJobs; i++) {
			if(x[i][0]>0){System.out.println(" Player selected "+i);}
		}
		System.out.println();
		System.out.println("*****Second entry:");		
		for (int i = 0; i < data.numJobs; i++) {
			if(x[i][1]>0){System.out.println(" Player selected "+i);}
		}
		System.out.println();
	}
	public double solveSubproblem(DataHandler data, PrintStream ps) {
			boolean improvesUB = false;
			//printSol(data);
			// Calculate real monster!!!!

			double mu1 = getmu1(data);
			double mu2 = getmu2(data);
			double theta = gettheta(data); 
			double ub = 0;
			this.mu1 = mu1;
			this.mu2 = mu2;
			
			Gaussian normal = new Gaussian();

//			System.out.println("    GOT HERE "+theta);
					
			if(theta==0) {
				ub = mu1;
			}
			else {
				//System.out.println("WEPAAAAAAAAAAA 2 THETA "+theta);
				
				ub = mu1*normal.cdf((mu1-mu2)/theta)+mu2*normal.cdf((mu2-mu1)/theta)+theta*normal.pdf((mu1-mu2)/theta);
				System.out.println("Real Mu1 "+mu1+" Mu2: "+mu2+" ThetaSquared: "+(theta*theta)+" Theta: "+theta+" cdf1: "+normal.cdf((mu1-mu2)/theta)+" cdf2: "+normal.cdf((mu2-mu1)/theta)+" pdf: "+normal.pdf((mu1-mu2)/theta));
			}
//			System.out.println("    GOT HERE");

			
			if(ub<=UB) {
				UB = ub;
				improvesUB = true;
				for (int i = 0; i < data.numJobs; i++) {
					xstar[i][0]=x[i][0];
					xstar[i][1]=x[i][1];
				}
				mu1Star = this.mu1;
				mu2Star = this.mu2;
				rhoStar = rho;
				//ps.println(((System.nanoTime()-Atime)/1000000000)+" "+zstar+" "+zsingle+" "+mu1Star+" "+mu2Star+" "+LB+" "+UB+" "+numCuts);
				
				//printSol(data);
				
			}
			return ub;
	}

	
	private double gettheta(DataHandler data) {
		double theta = 0;
		double var1=0;
		double var2=0;
		double std1=0;
		double std2=0;
		double rho =0;
		double sumCov = 0;
		// Get variance
		for (int j = 0; j < data.numJobs; j++) {
			var1+=data.var[j]*x[j][0];
			var2+=data.var[j]*x[j][1];
		}
		for (int j = 0; j < data.numJobs; j++) {
			for (int q = 0; q < data.numJobs; q++) {
				if(j!=q) {
				var1+=data.cov[j][q]*x[j][0]*x[q][0];
				var2+=data.cov[j][q]*x[j][1]*x[q][1];
				}
			}
		}
		// Get standard dev
		std1 = Math.sqrt(var1);
		std2 = Math.sqrt(var2);
		// Get sum of cov
		for (int j = 0; j < data.numJobs; j++) {
			for (int q = 0; q < data.numJobs; q++) {
				sumCov+=data.cov[j][q]*x[j][0]*x[q][1];
			}
		}
		
		// Get correlation
		double aux = Math.sqrt(var1*var2);
		rho = sumCov/aux;
		if(aux==0) {rho=1;}
		this.rho = rho;
//		System.out.println("Var1: "+var1+" var2: "+var2+" std1: "+std1+" std2: "+std2+" Cov: "+sumCov+" rho: "+rho+" aux: "+aux);
//		System.out.println("EY: "+(var1+var2-2*rho*std1*std2));
		theta = Math.sqrt(Math.max(var1+var2-2*rho*std1*std2 , 0));
		return theta;
	}

	private double getmu2(DataHandler data) {
		double mu = 0;
		
		for (int j = 0; j < data.numJobs; j++) {
			mu+=data.mu[j]*x[j][1];
		}
		
	return mu;
	}

	private double getmu1(DataHandler data) {
		double mu = 0;
		
			for (int j = 0; j < data.numJobs; j++) {
				mu+=data.mu[j]*x[j][0];
			}
			
		return mu;
	}

	public void CuttingPlanes(DataHandler data , double timeLimit, PrintStream ps) throws IloException {
		cplex = new IloCplex();
		numCuts = 0;
		cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
		cplex.setParam(IloCplex.DoubleParam.TiLim, timeLimit);

		cplex.setOut(null);
		
		// Upper estimation
		IloNumVar thetaSquared = cplex.numVar(0, maxThetaSquared, IloNumVarType.Float);
		IloNumVar theta = cplex.numVar(0, maxTheta, IloNumVarType.Float);
		IloNumVar mu1 = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float); // Max between mu1 and mu2
		IloNumVar mu2 = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float); // Min between mu1 and mu2
		IloNumVar terms1and2 = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float); // First two terms of the upper bounding function
		IloNumVar term3 = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float); // Third term of the upper bounding function
		IloNumVar[][] x = new IloNumVar[data.numJobs][2];

		// Linearization variables
		IloNumVar[][][] v = new IloNumVar[data.numJobs][data.numJobs][2];
		IloNumVar[][] r = new IloNumVar[data.numJobs][data.numJobs];
	
		// Discretization variables
		IloNumVar[] w = new IloNumVar[data.numPoints];
		IloNumVar[] y = new IloNumVar[data.numPointsD];
				
		//Create variables 
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numJobs; j++) {
				x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
		}
		for (int k = 0; k < 2; k++) {
			for (int j = 0; j <data.numJobs; j++) {
				for (int q = 0; q <data.numJobs; q++) {
					if(j!=q && data.cov[j][q]!=0) { v[j][q][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else { v[j][q][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
		}
		for (int j = 0; j <data.numJobs; j++) {
			for (int q = 0; q <data.numJobs; q++) {
				if(data.cov[j][q]!=0) {r[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);}
				else {r[j][q] = cplex.numVar(0, 0, IloNumVarType.Float);}
			}
		}
		for (int i = 0; i <data.numPoints-1; i++) {
			w[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}
			w[data.numPoints-1] = cplex.numVar(0, 0, IloNumVarType.Bool);
		for (int i = 0; i < data.numPointsD-1; i++) {
			y[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}
			y[data.numPointsD-1] = cplex.numVar(0, 0, IloNumVarType.Bool);
		//Add Jobs constraint
			for (int j = 0; j <data.numJobs; j++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				for (int k = 0; k < data.numMachines; k++) {
					expr.addTerm(1, x[j][k]);
				}
				cplex.addEq(expr, 1);
			}

			// Add linearization constraints I
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numJobs; j++) {
					for (int q = 0; q <data.numJobs; q++) {
						if(j!=q && data.cov[j][q]!=0) {
							
								IloLinearNumExpr lExpr = cplex.linearNumExpr();
								lExpr.addTerm(1, v[j][q][k]);
								lExpr.addTerm(-1, x[j][k]);
								cplex.addLe(lExpr, 0);
	
								IloLinearNumExpr lExprb = cplex.linearNumExpr();
								lExprb.addTerm(1, v[j][q][k]);
								lExprb.addTerm(-1, x[q][k]);
								cplex.addLe(lExprb, 0);
			
								IloLinearNumExpr lExprc = cplex.linearNumExpr();
								lExprc.addTerm(-1, v[j][q][k]);
								lExprc.addTerm(1, x[j][k]);
								lExprc.addTerm(1, x[q][k]);
								cplex.addLe(lExprc, 1);
							
						}
					}
				}
			}
			// Add linearization constraints II
			for (int j = 0; j <data.numJobs; j++) {
				for (int q = 0; q <data.numJobs; q++) {
					if(data.cov[j][q]!=0) {
						
							IloLinearNumExpr lExpr = cplex.linearNumExpr();
							lExpr.addTerm(1, r[j][q]);
							lExpr.addTerm(-1, x[j][0]);
							cplex.addLe(lExpr, 0);
	
							IloLinearNumExpr lExprb = cplex.linearNumExpr();
							lExprb.addTerm(1, r[j][q]);
							lExprb.addTerm(-1, x[q][1]);
							cplex.addLe(lExprb, 0);
						
							IloLinearNumExpr lExprc = cplex.linearNumExpr();
							lExprc.addTerm(-1, r[j][q]);
							lExprc.addTerm(1, x[j][0]);
							lExprc.addTerm(1, x[q][1]);
							cplex.addLe(lExprc, 1);
						
					}
				}
			}
			// Add Theta Squared constraint
			IloLinearNumExpr lExpr = cplex.linearNumExpr();
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numJobs; j++) {
						lExpr.addTerm(data.var[j], x[j][k]);
						
					for (int q = 0; q <data.numJobs; q++) {
						if(j!=q && data.cov[j][q]!=0) {
							lExpr.addTerm(data.cov[j][q], v[j][q][k]);
						}
					}
				}
			}
			for (int j = 0; j <data.numJobs; j++) {
				for (int q = 0; q <data.numJobs; q++) {
					if(data.cov[j][q]!=0) {
						lExpr.addTerm(-2*data.cov[j][q], r[j][q]);
					}
				}
			}
			lExpr.addTerm(-1, thetaSquared);
			cplex.addEq(lExpr, 0);			
			
		// Add discretization constraints
		// theta = some image
		IloLinearNumExpr dExpr = cplex.linearNumExpr();
		for (int i = 0; i <data.numPoints-1; i++) {
				dExpr.addTerm(Math.sqrt(intervalLimits1[i]), w[i]);
		}
		dExpr.addTerm(-1, theta);
		cplex.addEq(dExpr, 0);
		// Sum of w_i = 1
		IloLinearNumExpr qExpr = cplex.linearNumExpr();
		for (int i = 0; i <data.numPoints-1; i++) {
				qExpr.addTerm(1, w[i]);
		}
		cplex.addEq(qExpr, 1);
		// w_q activation
		for (int i = 0; i < data.numPoints-1; i++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			expr.addTerm(-intervalLimits1[i], w[i]);
			expr.addTerm(1, thetaSquared);
			cplex.addGe(expr, 0);
			
			IloLinearNumExpr expr2 = cplex.linearNumExpr();
			expr2.addTerm(1, thetaSquared);
			expr2.addTerm( maxThetaSquared, w[i]);
			cplex.addLe(expr2, intervalLimits1[i+1] + maxThetaSquared);
			
		}
		// Symmetry breaking
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int j = 0; j <data.numJobs; j++) {
				exprS.addTerm(data.mu[j], x[j][0]);
				exprS.addTerm(-data.mu[j], x[j][1]);
		}
		cplex.addGe(exprS, 0);
	
	// Add mu definition constraints
	IloLinearNumExpr expr = cplex.linearNumExpr();
	IloLinearNumExpr expr2 = cplex.linearNumExpr();
	for (int j = 0; j < data.numJobs; j++) {
			expr.addTerm(data.mu[j], x[j][0]);
			expr2.addTerm(data.mu[j], x[j][1]);
	}
	expr.addTerm(-1, mu1);
	expr2.addTerm(-1, mu2);
	cplex.addEq(expr, 0);
	cplex.addEq(expr2, 0);	
	
	// Mu difference Discretization 
	// y_k activation 
	for (int k = 0; k < data.numPointsD-1; k++) {
		IloLinearNumExpr expr3 = cplex.linearNumExpr();
		expr3.addTerm(1, mu1);
		expr3.addTerm(-1, mu2);
		expr3.addTerm(-intervalLimits2[k], y[k]);
		cplex.addGe(expr3, 0);
	
		IloLinearNumExpr expr4 = cplex.linearNumExpr();
		expr4.addTerm(1, mu1);
		expr4.addTerm(-1, mu2);
		expr4.addTerm(maxDelta, y[k]);
		cplex.addLe(expr4, intervalLimits2[k+1]+maxDelta);
		
	}
	// Sum of y_k = 1
	IloLinearNumExpr kExpr = cplex.linearNumExpr();
	for (int k = 0; k <data.numPointsD-1; k++) {
			kExpr.addTerm(1, y[k]);
	}
	cplex.addEq(kExpr, 1);

	// upper bounding function
	Gaussian normal = new Gaussian();
	// Bounds for terms 1 and 2
	for (int q = 0; q < data.numPoints-1; q++) {
		for (int k = 0; k < data.numPointsD-1; k++) {
			IloLinearNumExpr expr3 = cplex.linearNumExpr();
			double cdf;
			if(q==0) {cdf = 1;}
			else {cdf = normal.cdf( (intervalLimits2[k])/Math.sqrt(intervalLimits1[q+1]) )-0.001;}	//0.001 numeric tolerance			
			expr3.addTerm(cdf, mu1);
			expr3.addTerm(1-cdf, mu2);
			expr3.addTerm(maxDelta, y[k]);
			expr3.addTerm(maxDelta, w[q]);
			expr3.addTerm(-1, terms1and2);
			//System.out.println("q: "+q+" k: "+k+" deltaU: "+intervalLimits2[k+1]+" thetaL: "+Math.sqrt(intervalLimits1[q])+" CDF: "+cdf);
			cplex.addLe(expr3, 2*maxDelta);
		}

	}
	// Add basic bound
	IloLinearNumExpr expr5 = cplex.linearNumExpr();
	expr5.addTerm(1, terms1and2);
	expr5.addTerm(-1, mu1);
	cplex.addGe(expr5, 0);
	
	// Bounds for terms 3
	double M = (1/Math.sqrt(2*Math.PI))*maxTheta; 
	for (int q = 0; q < data.numPoints-1; q++) {
		for (int k = 0; k < data.numPointsD-1; k++) {
			IloLinearNumExpr expr3 = cplex.linearNumExpr();
			double pdf = normal.pdf( (intervalLimits2[k+1])/Math.sqrt(intervalLimits1[q]))-0.001; //0.001 numeric tolerance				
			expr3.addTerm(-M, y[k]);
			expr3.addTerm(-M, w[q]);
			expr3.addTerm(1, term3);
			//System.out.println("q: "+q+" k: "+k+" deltaL: "+intervalLimits2[k]+" thetaU: "+Math.sqrt(intervalLimits1[q+1])+" PDF: "+pdf);
			cplex.addGe(expr3, Math.sqrt(intervalLimits1[q])*pdf-2*M);
		}
	}

	// Add bound on delta(x)
	IloLinearNumExpr expr4 = cplex.linearNumExpr();
	expr4.addTerm(1, mu1);
	expr4.addTerm(-1, mu2);
	cplex.addLe(expr4, maxDelta);
	
	// ADD OBJECTIVE FUNCTION	
	IloLinearNumExpr obj = cplex.linearNumExpr();
	obj.addTerm(1 , terms1and2);
	obj.addTerm(1 , term3);
	cplex.addMinimize(obj,"ExpectedScore");


	

	boolean stop = false;
	while (stop==false) {
		cplex.solve();
		
		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		B&C is infeasible after adding some cuts - OPTIMAL SOL FOUND");
			zstar = UB;
			LB = UB; 
			stop = true;
			printSolStar(data);
		}
		else if((System.nanoTime()-Atime)/1000000000<=timeLimit ){
			System.out.println("THETA SQUARED: "+cplex.getValue(thetaSquared)+" THETA: "+cplex.getValue(theta));
			System.out.println("mu1: "+cplex.getValue(mu1)+" mu2: "+cplex.getValue(mu2));
			System.out.println("Terms 1 and 2: "+cplex.getValue(terms1and2)+" Term 3: "+cplex.getValue(term3));
	/*		for (int i = 0; i < data.numPoints-1; i++) {
				if(cplex.getValue(w[i])>0.1) System.out.println("w_"+i+" = 1 lowerLimit: "+intervalLimits1[i]+" upper limit: "+intervalLimits1[i+1] );
			}
			for (int i = 0; i < data.numPointsD-1; i++) {
				if(cplex.getValue(y[i])>0.1) System.out.println("y_"+i+" = 1 lowerLimit: "+intervalLimits2[i]+" upper limit: "+intervalLimits2[i+1] );
			}	*/
			LB = cplex.getObjValue();
	  		  for (int k = 0; k < 2; k++) {
				  for (int j = 0; j <data.numJobs; j++) {
					  this.x[j][k] = (int) Math.round(cplex.getValue(x[j][k]));
				  }
			  }
			double realObj = solveSubproblem(data , ps);
			double e = ( realObj - cplex.getObjValue() )/realObj;
			System.out.println("FAKE OBJ: "+( cplex.getObjValue() ) + " REAL OBJ "+realObj+" Error: "+e);
			error+= e;
			errorCount++;

			// Add no-good cut 1 
			int rhs = 0;
			IloLinearNumExpr exprA = cplex.linearNumExpr();
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numJobs; j++) {
					if(this.x[j][k]==1) {
						exprA.addTerm(1, x[j][k]);
						rhs++;
					}
				}
			}
			cplex.addLe(exprA, rhs-1);
			numCuts++;

			// Add no-good cut 2 (mirror!) 
			IloLinearNumExpr exprB = cplex.linearNumExpr();
			for (int j = 0; j <data.numJobs; j++) {
				if(this.x[j][0]==1) {
					exprB.addTerm(1, x[j][1]);
				}
				if(this.x[j][1]==1) {
					exprB.addTerm(1, x[j][0]);
				}
			}
			cplex.addLe(exprB, rhs-1);
			numCuts++;

			iterations++;
			if((UB-LB)/LB<0.001) {
				System.out.println("******OPTIMAL CERTIFICATE******NumCuts: "+numCuts+" LB: "+LB+" UB: "+UB);
				optimalFound = true;
				stop = true;
				printSolStar(data);
			}

			System.out.println("**********************************************NumCuts: "+numCuts+" LB: "+LB+" UB: "+UB);

			
		}
		else {
 	        System.out.println("Stop early - TIME LIMIT");
		        zstar = -1;
		        LB = Math.max(LB, cplex.getBestObjValue());
		        stop = true;
		} 

	
	
	
	}
	

	
	}

	
	
	public void genDiscretization(DataHandler data) throws IloException {
		getMaxThetaS(data);		// Compute an upper bound on theta squared and theta
		genThetaLinPoints(data);

		maxDelta = 0.1;
		for (int i = 0; i < data.numJobs; i++) {
			maxDelta+=data.mu[i];
		}
		System.out.println("MAX DELTA "+maxDelta);	
		
		// Gen Discretization points
		intervalLimits2 = new double[data.numPointsD];
		
		double step = (maxDelta)/(data.numPointsD-1);
		for (int i = 0; i < data.numPointsD; i++) {
			intervalLimits2[i] = 0+step*i;
		}
		
		
		System.out.println("THETA INTERVALS: ");
		for (int i = 0; i < intervalLimits1.length; i++) {
			System.out.print(intervalLimits1[i]+" ");
		}
		System.out.println();

		System.out.println("DELTA INTERVALS: ");
		for (int i = 0; i < intervalLimits2.length; i++) {
			System.out.print(intervalLimits2[i]+" ");
		}
		System.out.println();
	
	
		
	}


	private void genThetaLinPoints(DataHandler data) {
		// Gen Discretization points
		intervalLimits1 = new double[data.numPoints];
		
		intervalLimits1[0] = 0;
		intervalLimits1[1] = 1;
		
		double step = (maxThetaSquared-1)/(data.numPoints-2);
		for (int i = 2; i < data.numPoints; i++) {
			intervalLimits1[i] = intervalLimits1[i-1]+step;
		}

		
	}

	private void genDeltaLinPoints(DataHandler data) {
		// Gen Discretization points
		intervalLimits2 = new double[data.numPointsD];
		
		double step = (maxDelta)/(data.numPointsD-1);
		for (int i = 0; i < data.numPointsD; i++) {
			intervalLimits2[i] = 0+step*i;
		}

		
	}
	



	public void getMaxThetaS(DataHandler data) throws IloException {
			cplex = new IloCplex();
			cplex.setParam(IloCplex.IntParam.MIPEmphasis, 3);
			cplex.setParam(IloCplex.DoubleParam.TiLim, 120);
			cplex.setOut(null);

			// Upper estimation
			IloNumVar thetaSquared = cplex.numVar(0, Double.MAX_VALUE, IloNumVarType.Float);
			IloNumVar[][] x = new IloNumVar[data.numJobs][2];

			// Linearization variables
			IloNumVar[][][] v = new IloNumVar[data.numJobs][data.numJobs][2];
			IloNumVar[][] r = new IloNumVar[data.numJobs][data.numJobs];
		
			// Discretization variables
			IloNumVar[] w = new IloNumVar[data.numPoints];
			IloNumVar[] y = new IloNumVar[data.numPointsD];
					
			//Create variables 
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numJobs; j++) {
					x[j][k] = cplex.numVar(0, 1, IloNumVarType.Bool);
				}
			}
			for (int k = 0; k < 2; k++) {
				for (int j = 0; j <data.numJobs; j++) {
					for (int q = 0; q <data.numJobs; q++) {
						if(j!=q && data.cov[j][q]!=0) { v[j][q][k] = cplex.numVar(0, 1, IloNumVarType.Bool);}
						else { v[j][q][k] = cplex.numVar(0, 0, IloNumVarType.Float);}
					}
				}
			}
			for (int j = 0; j <data.numJobs; j++) {
				for (int q = 0; q <data.numJobs; q++) {
					if(data.cov[j][q]!=0) {r[j][q] = cplex.numVar(0, 1, IloNumVarType.Bool);}
					else {r[j][q] = cplex.numVar(0, 0, IloNumVarType.Float);}
				}
			}
			for (int i = 0; i <data.numPoints-1; i++) {
				w[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
				w[data.numPoints-1] = cplex.numVar(0, 0, IloNumVarType.Bool);
			for (int i = 0; i < data.numPointsD-1; i++) {
				y[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
			}
				y[data.numPointsD-1] = cplex.numVar(0, 0, IloNumVarType.Bool);
			//Add Jobs constraint
				for (int j = 0; j <data.numJobs; j++) {
					IloLinearNumExpr expr = cplex.linearNumExpr();
					for (int k = 0; k < data.numMachines; k++) {
						expr.addTerm(1, x[j][k]);
					}
					cplex.addEq(expr, 1);
				}

				// Add linearization constraints I
				for (int k = 0; k < 2; k++) {
					for (int j = 0; j <data.numJobs; j++) {
						for (int q = 0; q <data.numJobs; q++) {
							if(j!=q && data.cov[j][q]!=0) {
								
									IloLinearNumExpr lExpr = cplex.linearNumExpr();
									lExpr.addTerm(1, v[j][q][k]);
									lExpr.addTerm(-1, x[j][k]);
									cplex.addLe(lExpr, 0);
		
									IloLinearNumExpr lExprb = cplex.linearNumExpr();
									lExprb.addTerm(1, v[j][q][k]);
									lExprb.addTerm(-1, x[q][k]);
									cplex.addLe(lExprb, 0);
				
									IloLinearNumExpr lExprc = cplex.linearNumExpr();
									lExprc.addTerm(-1, v[j][q][k]);
									lExprc.addTerm(1, x[j][k]);
									lExprc.addTerm(1, x[q][k]);
									cplex.addLe(lExprc, 1);
								
							}
						}
					}
				}
				// Add linearization constraints II
				for (int j = 0; j <data.numJobs; j++) {
					for (int q = 0; q <data.numJobs; q++) {
						if(data.cov[j][q]!=0) {
							
								IloLinearNumExpr lExpr = cplex.linearNumExpr();
								lExpr.addTerm(1, r[j][q]);
								lExpr.addTerm(-1, x[j][0]);
								cplex.addLe(lExpr, 0);
		
								IloLinearNumExpr lExprb = cplex.linearNumExpr();
								lExprb.addTerm(1, r[j][q]);
								lExprb.addTerm(-1, x[q][1]);
								cplex.addLe(lExprb, 0);
							
								IloLinearNumExpr lExprc = cplex.linearNumExpr();
								lExprc.addTerm(-1, r[j][q]);
								lExprc.addTerm(1, x[j][0]);
								lExprc.addTerm(1, x[q][1]);
								cplex.addLe(lExprc, 1);
							
						}
					}
				}
				// Add Theta Squared constraint
				IloLinearNumExpr lExpr = cplex.linearNumExpr();
				for (int k = 0; k < 2; k++) {
					for (int j = 0; j <data.numJobs; j++) {
							lExpr.addTerm(data.var[j], x[j][k]);
							
						for (int q = 0; q <data.numJobs; q++) {
							if(j!=q && data.cov[j][q]!=0) {
								lExpr.addTerm(data.cov[j][q], v[j][q][k]);
							}
						}
					}
				}
				for (int j = 0; j <data.numJobs; j++) {
					for (int q = 0; q <data.numJobs; q++) {
						if(data.cov[j][q]!=0) {
							lExpr.addTerm(-2*data.cov[j][q], r[j][q]);
						}
					}
				}
				lExpr.addTerm(-1, thetaSquared);
				cplex.addEq(lExpr, 0);
	
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		obj.addTerm(1, thetaSquared);
		cplex.addMaximize(obj,"ThetaSquared");
		cplex.solve();
		
			if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
				System.out.println("		Theta Bounder is infeasible!");		
			}
			else{
				maxThetaSquared = cplex.getBestObjValue();
				maxTheta = Math.sqrt(maxThetaSquared);
				System.out.println("MAX THETA SQUARED IS: "+maxThetaSquared+" MAX THETA: "+maxTheta);
				
/*				for (int k = 0; k < 2; k++) {
					for (int j = 0; j <data.numJobs; j++) {
						for (int q = 0; q <data.numJobs; q++) {
							if(j!=q && data.cov[j][q]!=0 && cplex.getValue(v[j][q][k])>0.1) {System.out.println("v"+j+","+q+","+k+" xvars "+cplex.getValue(x[j][k])+" and "+cplex.getValue(x[q][k]));}
						}
					}
				}
*/				
				cplex.clearModel();
				cplex.end();
				System.gc();
			}
		}

	

	
	
	
}
