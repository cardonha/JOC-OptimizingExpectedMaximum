/**
 * This class holds all the data.
 * 
 * Ref.: Lozano, L. and Smith, J. C. (2015). 
 * A Sampling-Based Exact Approach for the Bilevel Mixed Integer Programming Problem
 * 
 * @author L. Lozano & J. C. Smith
 * @affiliation Clemson University
 * @url www.leo-loza.com
 * 
 */
package OptimalKEntries;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Random;
import java.util.StringTokenizer;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class DataHandler {
	// Number of items
	public int numJobs;

	// Number of Bins
	public int numMachines;

	// Number of simulations
	public int numSim;

	// Expected time for a job
	double[] mu;

	// Simulated time for an item
	double[][] sim;

	// 100 Oracles profit for an item
	double[][][] oracle;

	// Variance
	double[] var;

	// Covariance for a pair of items
	double[][] cov;

	// number of discrete points to approx a sqrt
	int numPoints;

	// number of discrete points to approx delta(x)
	int numPointsD;
	
	//Big Ms
	double [] M;

	// Read data from an instance
	public DataHandler(int nDiscrete, int nDis2, int numE) {
		numPoints = nDiscrete;
		numPointsD = nDis2;
		numMachines = numE;
	}
	public void readInstanceTXT(String filename) throws IOException {

		File file = new File(filename);
		BufferedReader bufRdr = new BufferedReader(new FileReader(file));

		// Read num vars
		String line = bufRdr.readLine();
		String[] splited = line.split(" ");
		
		numJobs = Integer.parseInt(splited[0]);
		System.out.println("WEPAAAA num vars: "+numJobs);
		
		// Initialize vectors
		mu = new double[numJobs];
		var  = new double[numJobs];
		cov = new double[numJobs][numJobs];
		String[] readed = new String[numJobs];

		int row = 0;
		int col = 0;
		// Read data
		while ( row < numJobs+1 && (line = bufRdr.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, " ");
			while (st.hasMoreTokens()) {
				// get next token and store it in the array
				readed[col] = st.nextToken();
				col++;
			}
			for (int i = 0; i < numJobs; i++) {
				if(row==0) {
					mu[i] = round(Double.parseDouble(readed[i]));
				}
				else {
					cov[row-1][i] = round(Double.parseDouble(readed[i]));
				}
				var[i] = cov[i][i];
			}
			col = 0;
			row++;
		}
		
		// Print
/*		for (int i = 0; i < numJobs; i++) {
			System.out.println("Job "+i+" mu: "+mu[i]+" var: "+var[i]);
			for (int j = 0; j < numJobs; j++) {
				System.out.print(cov[i][j]+" ");
			}
			System.out.println();
		}
*/

	}
	public void readSimulationInstance(String name, int numSimulations) throws IOException {

		numSim = numSimulations;
		
		File file = new File("data/"+name);
		BufferedReader bufRdr = new BufferedReader(new FileReader(file));

		// Read num vars
		String line = bufRdr.readLine();
		String[] splited = line.split(" ");
		
		numJobs = Integer.parseInt(splited[0]);
		
		// Initialize vectors
		sim = new double[numJobs][numSim];
		mu = new double[numJobs];
		var  = new double[numJobs];
		cov = new double[numJobs][numJobs];
		String[] readed = new String[numJobs];

		int row = 0;
		int col = 0;
		// Read data
		while ( row < numJobs+1 && (line = bufRdr.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, " ");
			while (st.hasMoreTokens()) {
				// get next token and store it in the array
				readed[col] = st.nextToken();
				col++;
			}
			for (int i = 0; i < numJobs; i++) {
				if(row==0) {
					mu[i] = round(Double.parseDouble(readed[i]));
				}
				else {
					cov[row-1][i] = round(Double.parseDouble(readed[i]));
				}
				var[i] = cov[i][i];
			}
			col = 0;
			row++;
		}
		
		// Print
/*		for (int i = 0; i < numJobs; i++) {
			System.out.println("Job "+i+" mu: "+mu[i]+" var: "+var[i]);
			for (int j = 0; j < numJobs; j++) {
				System.out.print(cov[i][j]+" ");
			}
			System.out.println();
		}
*/
		
// READ THE SIMULATED SCORE VECTORS
		
		File file2 = new File("EvalOracle/simulation-"+name);
		bufRdr = new BufferedReader(new FileReader(file2));

		//Kill one line
		line = bufRdr.readLine();
		// Read num vars
		line = bufRdr.readLine();
		splited = line.split(" ");
		
		System.out.println("WEPAAAA READING SIMULATIONS");
		
		readed = new String[numJobs];
		row = 0;
		col = 0;
		// Read data
		while ( row < numSim && (line = bufRdr.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, " ");
			while (st.hasMoreTokens()) {
				// get next token and store it in the array
				readed[col] = st.nextToken();
				col++;
			}
			for (int i = 0; i < numJobs; i++) {
				sim[i][row] = Double.parseDouble(readed[i]);
			}
			col = 0;
			row++;
		}

			
/*		// Print
		for (int i = 0; i < numSim; i++) {
			System.out.print("sim vector "+i+": ");
			for (int j = 0; j < numJobs; j++) {
				System.out.print(sim[j][i]+" ");
			}
			System.out.println();
		}
*/		

		
	}
	public double round(double value) {
		double rounded;
		
		rounded = Math.round(value*1000)/1000.0;
		
		return rounded;
	}

	public void readOracle(String name) throws NumberFormatException, IOException {
		
		File file2 = new File("EvalOracle/simulation-"+name);
		BufferedReader bufRdr = new BufferedReader(new FileReader(file2));
		
		// Initialize oracle
		oracle = new double[numJobs][50][100];
		String[] readed = new String[numJobs];
		
// READ THE SIMULATED SCORE VECTORS
		// Kill one line
		String line = bufRdr.readLine();
		// Read num vars
		line = bufRdr.readLine();
		String[] splited = line.split(" ");
				
		System.out.println("WEPAAAA READING ORACLE");
		
		readed = new String[numJobs];
		
		for (int h = 0; h < 100; h++) {
			int row = 0;
			int col = 0;
			// Read data
			while ( row < 50 && (line = bufRdr.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, " ");
				while (st.hasMoreTokens()) {
					// get next token and store it in the array
					readed[col] = st.nextToken();
					col++;
				}
				for (int i = 0; i < numJobs; i++) {
					oracle[i][row][h] = Double.parseDouble(readed[i]);
					
				}
				col = 0;
				row++;
				
			}
		}
			
		// Print
/*		for (int h = 0; h < 100; h++) {
			System.out.println("ORACLE BATCH "+h);
			for (int i = 0; i < 50; i++) {
				System.out.print("oracle vector "+i+": ");
				for (int j = 0; j < numJobs; j++) {
					System.out.print(oracle[j][i][h]+" ");
				}
				System.out.println();
			}
		}		
*/

	}



}

