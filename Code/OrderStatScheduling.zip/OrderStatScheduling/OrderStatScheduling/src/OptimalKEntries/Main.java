/**
 * This is the main class for the cutting-plane algorithm.
 * 
 * Ref.: Bergman, Cardonha, Lozano, Imbrogno (2018). 
 * 
 * 
 * @author L. Lozano
 * @affiliation University of Cincinnati
 * 
 */
package OptimalKEntries;

import ilog.concert.IloException;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException, InterruptedException, IloException {

		String[] A = {"0.25","0.5","0.75"};
		for (int n = 15; n <= 30; n+=5) {
			for (int a = 0; a <= 2; a+=1) {
				for (int k = 2; k <= 4; k+=1) {
					for (int s = 0; s <= 4; s++) {
						String name=n+"-"+A[a]+"-"+k+"-"+s;
						//runTwoEntry(name , 600);
						//runSimulationOpti(name , 600);
						runHeuristic(name, 600);
					}
				}
			}
		}
	}

	private static void runTwoEntry(String dataFile , double tLimit) throws IOException, InterruptedException, IloException {

		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream("ResultsEXACTNEW.txt", true));
		
		// Read a config file with the instance information: Num discrete points for linearization
		DataHandler data = new DataHandler(50, 50, 2);
		data.readInstanceTXT("data/"+dataFile);

		// Create an AlgorithmHandler
		AlgorithmHandler alg = new AlgorithmHandler(data);

		// Begin the time count						
		alg.Atime = System.nanoTime();
		alg.genDiscretization(data);
		alg.CuttingPlanes(data , tLimit, ps);

		System.out.println("            EXECUTION TIME: "+((System.nanoTime()-alg.Atime)/1000000000));
		ps.println(dataFile+" "+((System.nanoTime()-alg.Atime)/1000000000)+" "+alg.mu1Star+" "+alg.mu2Star+" "+alg.LB+" "+alg.UB+" "+alg.numCuts+" "+(alg.error/alg.errorCount));
		alg.cplex.clearModel();
		alg.cplex.end();
		System.gc();

	}

	private static void runHeuristic(String dataFile , double tLimit) throws IOException, InterruptedException, IloException {

		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream("ResultsHeuristic.txt", true));
		
		// Read a config file with the instance information: Num discrete points for linearization
		DataHandler data = new DataHandler(0, 0, 2);
		data.readInstanceTXT("data/"+dataFile);
		data.readOracle(dataFile);
		
		// Create an AlgorithmHandler
		AlgorithmHandler alg = new AlgorithmHandler(data);

		// Begin the time count						
		alg.Atime = System.nanoTime();
		alg.solveHeuristic(data); // Receives delta
		
		
		System.out.println("            EXECUTION TIME: "+((System.nanoTime()-alg.Atime)/1000000000));
		ps.println(dataFile+" "+((System.nanoTime()-alg.Atime)/1000000000)+" "+alg.mu1Star+" "+alg.mu2Star+" "+alg.zheuristic+" "+" "+alg.zheuristicREAL);
		//ps.println(dataFile+" "+alg.zheuristic);
		alg.cplex.clearModel();
		alg.cplex.end();
		System.gc();

	}

	
	
}